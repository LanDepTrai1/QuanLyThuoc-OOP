@echo off
cd /d "%~dp0"
chcp 65001 > nul
cls
echo ========================================================
echo   KHOI DONG HE THONG QUAN LY THUOC VA Y TE
echo ========================================================
echo.
echo [1/2] Dang kiem tra va bien dich ma nguon...
if not exist out mkdir out
javac --release 11 -encoding UTF-8 -d out src\QuanLyThuoc\*.java src\QuanLyKhachHang\*.java src\QuanLyNhanVien\*.java src\QuanLyHoaDon\*.java src\Main.java
if %ERRORLEVEL% NEQ 0 (
    echo [!] Bien dich that bai! Vui long kiem tra lai ma nguon.
    pause
    exit /b %ERRORLEVEL%
)
echo [2/2] Khoi chay chuong trinh...
echo.
java "-Dfile.encoding=UTF-8" -cp out Main
pause
