import java.util.Scanner;
import QuanLyThuoc.QuanLyThuoc;
import QuanLyThuoc.Thuoc;
import QuanLyKhachHang.QuanLyKhachHang;
import QuanLyKhachHang.KhachHang;
import QuanLyNhanVien.QuanLyNhanVien;
import QuanLyNhanVien.NhanVien;
import QuanLyNhanVien.NhanVienBanHang;
import QuanLyHoaDon.QuanLyHoaDon;
import QuanLyHoaDon.HoaDon;

public class Main {

    public static void main(String[] args) {
        // Cấu hình UTF-8 cho console Windows
        try {
            System.setOut(new java.io.PrintStream(System.out, true, java.nio.charset.StandardCharsets.UTF_8));
        } catch (Exception ignored) {}

        if (System.getProperty("os.name").toLowerCase(java.util.Locale.ROOT).contains("win")) {
            try {
                new ProcessBuilder("cmd.exe", "/c", "chcp 65001 > nul")
                        .inheritIO()
                        .start()
                        .waitFor();
            } catch (Exception ignored) {}
        }

        Scanner sc = new Scanner(System.in);
        QuanLyThuoc qlThuoc = new QuanLyThuoc();
        QuanLyKhachHang qlKhachHang = new QuanLyKhachHang();
        QuanLyNhanVien qlNhanVien = new QuanLyNhanVien();
        QuanLyHoaDon qlHoaDon = new QuanLyHoaDon();

        qlThuoc.setScanner(sc);
        qlKhachHang.setScanner(sc);
        qlNhanVien.setScanner(sc);
        qlHoaDon.setScanner(sc);

        // Tự động đồng bộ doanh số nhân viên từ các hóa đơn thực tế
        qlNhanVien.dongBoDoanhSoTuHoaDon(qlHoaDon);

        int luaChonDangNhap = -1;
        do {
            System.out.println("\n╔══════════════════════════════════════════════════╗");
            System.out.println("║        HỆ THỐNG QUẢN LÝ NHÀ THUỐC VÀ Y TẾ        ║");
            System.out.println("╠══════════════════════════════════════════════════╣");
            System.out.println("║  1. Đăng nhập Quản trị viên (Admin)              ║");
            System.out.println("║  2. Đăng nhập Nhân viên bán hàng                 ║");
            System.out.println("║  0. Thoát chương trình                           ║");
            System.out.println("╚══════════════════════════════════════════════════╝");
            System.out.print("Nhập lựa chọn của bạn: ");

            try {
                luaChonDangNhap = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println(">>> Vui lòng nhập số!");
                continue;
            }

            switch (luaChonDangNhap) {
                case 1:
                    dangNhapAdmin(sc, qlThuoc, qlKhachHang, qlNhanVien, qlHoaDon);
                    break;
                case 2:
                    dangNhapNhanVien(sc, qlThuoc, qlKhachHang, qlNhanVien, qlHoaDon);
                    break;
                case 0:
                    System.out.println("\n>>> Cảm ơn bạn đã sử dụng chương trình. Tạm biệt!");
                    break;
                default:
                    System.out.println(">>> Lựa chọn không hợp lệ! Vui lòng chọn 0, 1 hoặc 2.");
            }
        } while (luaChonDangNhap != 0);
    }

    // ==================== ĐĂNG NHẬP ADMIN ====================
    private static void dangNhapAdmin(Scanner sc, QuanLyThuoc qlThuoc, QuanLyKhachHang qlKhachHang,
                                      QuanLyNhanVien qlNhanVien, QuanLyHoaDon qlHoaDon) {
        System.out.println("\n----- ĐĂNG NHẬP QUẢN TRỊ VIÊN (ADMIN) -----");
        System.out.print("Tài khoản: ");
        String user = sc.nextLine().trim();
        System.out.print("Mật khẩu : ");
        String pass = sc.nextLine().trim();

        if (user.equalsIgnoreCase("admin") && (pass.equals("admin") || pass.equals("123456") || pass.equals("123"))) {
            System.out.println(">>> Đăng nhập thành công với quyền Quản trị viên!");
            menuAdmin(sc, qlThuoc, qlKhachHang, qlNhanVien, qlHoaDon);
        } else {
            System.out.println(">>> Sai tài khoản hoặc mật khẩu! (Mặc định: admin / admin)");
        }
    }

    // ==================== MENU ADMIN ====================
    private static void menuAdmin(Scanner sc, QuanLyThuoc qlThuoc, QuanLyKhachHang qlKhachHang,
                                  QuanLyNhanVien qlNhanVien, QuanLyHoaDon qlHoaDon) {
        int luaChon = -1;
        do {
            System.out.println("\n╔══════════════════════════════════════════════════╗");
            System.out.println("║           BẢNG ĐIỀU KHIỂN QUẢN TRỊ VIÊN          ║");
            System.out.println("╠══════════════════════════════════════════════════╣");
            System.out.println("║  1. Quản lý Thuốc & Vật tư y tế                  ║");
            System.out.println("║  2. Quản lý Khách hàng                           ║");
            System.out.println("║  3. Quản lý Nhân viên & Tiền lương               ║");
            System.out.println("║  4. Quản lý Hóa đơn & Bán hàng                   ║");
            System.out.println("║  5. Báo cáo thống kê tổng quan doanh thu         ║");
            System.out.println("║  0. Đăng xuất (Về màn hình chính)                ║");
            System.out.println("╚══════════════════════════════════════════════════╝");
            System.out.print("Nhập lựa chọn của bạn: ");

            try {
                luaChon = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println(">>> Vui lòng nhập số!");
                continue;
            }

            switch (luaChon) {
                case 1:
                    qlThuoc.hienMenu(sc);
                    break;
                case 2:
                    qlKhachHang.hienMenu(sc);
                    break;
                case 3:
                    qlNhanVien.hienMenu(sc);
                    break;
                case 4:
                    qlHoaDon.hienMenu(sc, qlThuoc, qlKhachHang, qlNhanVien);
                    break;
                case 5:
                    hienBaoCaoThongKe(qlThuoc, qlKhachHang, qlNhanVien, qlHoaDon);
                    break;
                case 0:
                    System.out.println(">>> Đã đăng xuất tài khoản Quản trị viên.");
                    break;
                default:
                    System.out.println(">>> Lựa chọn không hợp lệ! Vui lòng chọn từ 0 đến 5.");
            }
        } while (luaChon != 0);
    }

    // ==================== BÁO CÁO THỐNG KÊ ADMIN ====================
    private static void hienBaoCaoThongKe(QuanLyThuoc qlThuoc, QuanLyKhachHang qlKhachHang,
                                         QuanLyNhanVien qlNhanVien, QuanLyHoaDon qlHoaDon) {
        System.out.println("\n╔════════════════════════════════════════════════════════════════════════════════════════╗");
        System.out.println("║                          BÁO CÁO THỐNG KÊ HOẠT ĐỘNG NHÀ THUỐC                          ║");
        System.out.println("╠════════════════════════════════════════════════════════════════════════════════════════╣");

        // 1. Thuốc
        int tongThuoc = qlThuoc.getDanhSach().size();
        double tongGiaTriKho = 0;
        for (Thuoc t : qlThuoc.getDanhSach()) {
            tongGiaTriKho += t.getGiaBan() * t.getSoLuong();
        }
        System.out.printf("║  1. Kho hàng  : %-3d mặt hàng | Tổng giá trị tồn kho: %,15.0f VNĐ               ║%n",
                tongThuoc, tongGiaTriKho);

        // 2. Khách hàng
        int tongKH = qlKhachHang.getDanhSach().size();
        System.out.printf("║  2. Khách hàng: %-3d khách hàng đã đăng ký trong hệ thống                               ║%n", tongKH);

        // 3. Nhân viên
        int tongNV = qlNhanVien.getDanhSach().size();
        System.out.printf("║  3. Nhân sự   : %-3d nhân viên (Bán hàng và Kho)                                        ║%n", tongNV);

        // 4. Doanh thu từ hóa đơn
        int tongHD = qlHoaDon.getDanhSach().size();
        double tongDoanhThu = 0;
        for (HoaDon hd : qlHoaDon.getDanhSach()) {
            tongDoanhThu += hd.tinhThanhToan();
        }
        System.out.printf("║  4. Doanh thu : %-3d hóa đơn  | Tổng doanh thu bán ra: %,15.0f VNĐ              ║%n",
                tongHD, tongDoanhThu);

        System.out.println("╠════════════════════════════════════════════════════════════════════════════════════════╣");
        System.out.println("║  BẢNG DOANH SỐ VÀ LƯƠNG TẠM TÍNH NHÂN VIÊN BÁN HÀNG:                                   ║");
        qlNhanVien.dongBoDoanhSoTuHoaDon(qlHoaDon);
        for (NhanVien nv : qlNhanVien.getDanhSach()) {
            if (nv instanceof NhanVienBanHang) {
                NhanVienBanHang nvBH = (NhanVienBanHang) nv;
                String tenHienThi = nvBH.getTenNV();
                if (tenHienThi.length() > 15) {
                    tenHienThi = tenHienThi.substring(0, 15);
                }
                System.out.printf("║  - NV [%-5s] %-15s | Doanh số: %,10.0f | Lương tạm tính: %,11.0f VNĐ ║%n",
                        nvBH.getMaNV(), tenHienThi, nvBH.getDoanhSoThang(), nvBH.tinhLuong());
            }
        }
        System.out.println("╚════════════════════════════════════════════════════════════════════════════════════════╝");
    }

    // ==================== ĐĂNG NHẬP NHÂN VIÊN ====================
    private static void dangNhapNhanVien(Scanner sc, QuanLyThuoc qlThuoc, QuanLyKhachHang qlKhachHang,
                                         QuanLyNhanVien qlNhanVien, QuanLyHoaDon qlHoaDon) {
        System.out.println("\n----- ĐĂNG NHẬP DÀNH CHO NHÂN VIÊN BÁN HÀNG -----");
        System.out.print("Nhập Mã nhân viên của bạn: ");
        String maNV = sc.nextLine().trim();

        NhanVien nv = qlNhanVien.timTheoMa(maNV);
        if (nv == null) {
            System.out.println(">>> Không tìm thấy nhân viên có mã: " + maNV);
            System.out.println(">>> Gợi ý: Hãy nhờ Quản trị viên tạo tài khoản nhân viên trước.");
            return;
        }

        if (!(nv instanceof NhanVienBanHang)) {
            System.out.println(">>> Tài khoản này là [" + nv.getLoaiNV() + "], không có quyền truy cập chức năng Bán hàng.");
            return;
        }

        System.out.print("Nhập mật khẩu (mặc định: 123): ");
        String pass = sc.nextLine().trim();
        // Bắt buộc nhập đúng mật khẩu, không cho để trống
        if (pass.isEmpty()) {
            System.out.println(">>> Mật khẩu không được để trống!");
        } else if (pass.equals("123")) {
            NhanVienBanHang nvBH = (NhanVienBanHang) nv;
            System.out.printf(">>> Đăng nhập thành công! Xin chào: %s (%s)%n", nvBH.getTenNV(), nvBH.getMaNV());
            menuNhanVien(sc, nvBH, qlThuoc, qlKhachHang, qlNhanVien, qlHoaDon);
        } else {
            System.out.println(">>> Mật khẩu không đúng!");
        }
    }

    // ==================== MENU NHÂN VIÊN BÁN HÀNG ====================
    private static void menuNhanVien(Scanner sc, NhanVienBanHang nvBH, QuanLyThuoc qlThuoc,
                                    QuanLyKhachHang qlKhachHang, QuanLyNhanVien qlNhanVien,
                                    QuanLyHoaDon qlHoaDon) {
        int luaChon = -1;
        do {
            qlNhanVien.dongBoDoanhSoTuHoaDon(qlHoaDon);
            System.out.println("\n╔══════════════════════════════════════════════════╗");
            System.out.println("║          BẢNG LÀM VIỆC NHÂN VIÊN BÁN HÀNG        ║");
            System.out.printf("║  Xin chào: %-37s ║%n", nvBH.getTenNV() + " (" + nvBH.getMaNV() + ")");
            System.out.println("╠══════════════════════════════════════════════════╣");
            System.out.println("║  1. Tạo hóa đơn bán thuốc                        ║");
            System.out.println("║  2. Xem danh sách hóa đơn đã lập                 ║");
            System.out.println("║  3. Xem doanh số & Hoa hồng tạm tính             ║");
            System.out.println("║  4. Tra cứu thông tin thuốc & Giá bán            ║");
            System.out.println("║  5. Tra cứu khách hàng & Điểm tích lũy           ║");
            System.out.println("║  0. Đăng xuất (Về màn hình chính)                ║");
            System.out.println("╚══════════════════════════════════════════════════╝");
            System.out.print("Nhập lựa chọn của bạn: ");

            try {
                luaChon = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println(">>> Vui lòng nhập số!");
                continue;
            }

            switch (luaChon) {
                case 1:
                    // Tạo hóa đơn bán thuốc tự động gắn mã nhân viên và cộng doanh số
                    qlHoaDon.taoHoaDon(sc, nvBH.getMaNV(), qlThuoc, qlKhachHang, qlNhanVien);
                    break;
                case 2:
                    qlHoaDon.hienDanhSachTheoNV(nvBH.getMaNV());
                    break;
                case 3:
                    System.out.println("\n===== THÔNG TIN DOANH SỐ & HOA HỒNG TẠM TÍNH =====");
                    qlNhanVien.dongBoDoanhSoTuHoaDon(qlHoaDon);
                    nvBH.hienThongTinNhanVienXem();
                    break;
                case 4:
                    qlThuoc.timKiem();
                    break;
                case 5:
                    qlKhachHang.tìmKiếm();
                    break;
                case 0:
                    System.out.println(">>> Đã đăng xuất.");
                    break;
                default:
                    System.out.println(">>> Lựa chọn không hợp lệ! Vui lòng chọn từ 0 đến 5.");
            }
        } while (luaChon != 0);
    }
}
