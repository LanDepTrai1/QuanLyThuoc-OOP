package QuanLyKhachHang;

/**
 * Khách hàng VIP: được cấp thẳng Hạng Vàng (VIP) khi tạo,
 * không cần tích đủ điểm. Đến kỳ xét duyệt vẫn phải đạt điểm duy trì như mọi khách hàng.
 */
public class KhachHangVip extends KhachHang {

    public KhachHangVip() {
        super();
        setCapHang(CAP_VIP);
        demKH++;
    }

    public KhachHangVip(String maKH, String tenKH, String soDienThoai, String diaChi, double diemTichLuy) {
        super(maKH, tenKH, soDienThoai, diaChi, diemTichLuy);
        setCapHang(CAP_VIP);
        demKH++;
    }

    @Override
    public void hienThongTin() {
        System.out.println("----------------------------------------------------------------------");
        System.out.printf("Mã khách hàng               : %s%n", getMaKH());
        // Chỉ ghi "(Khách VIP)" khi khách còn giữ Hạng Vàng (VIP)
        if (getCapHang() == CAP_VIP) {
            System.out.printf("Tên khách hàng              : %s (Khách VIP)%n", getTenKH());
        } else {
            System.out.printf("Tên khách hàng              : %s%n", getTenKH());
        }
        System.out.printf("Số điện thoại               : %s%n", getSoDienThoai());
        System.out.printf("Địa chỉ                     : %s%n", getDiaChi());
        inThongTinHang();
        System.out.println("----------------------------------------------------------------------");
    }
}
