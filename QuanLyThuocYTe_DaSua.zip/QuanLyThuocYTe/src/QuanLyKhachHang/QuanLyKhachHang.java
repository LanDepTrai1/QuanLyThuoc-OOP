package QuanLyKhachHang;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class QuanLyKhachHang implements IKhachHangAction {
    // Tên file mặc định
    private static final String FILE_MAC_DINH = "khachhang.txt";

    private ArrayList<KhachHang> danhSach;
    private Scanner sc;
    // Thời điểm sửa đổi file lần cuối được nạp
    private long thoiGianDocFile = 0;

    // Constructor
    public QuanLyKhachHang() {
        danhSach = new ArrayList<>();
        sc = new Scanner(System.in);
        File file = new File(FILE_MAC_DINH);
        if (file.exists()) {
            đọcTệp(FILE_MAC_DINH);
        } else {
            File fileCu = new File("kh.txt");
            if (fileCu.exists()) {
                đọcTệp("kh.txt");
                ghiTệp(FILE_MAC_DINH);
            }
        }
        xetDuyetHangNeuDenHan();
    }

    // ==================== XÉT DUYỆT HẠNG ĐỊNH KỲ ====================
    // File lưu năm gần nhất đã xét duyệt hạng (kỳ xét duyệt chung: 31/12 hằng năm)
    private static final String FILE_XET_DUYET = "xetduyethang.txt";

    /**
     * Khi đã qua ngày 31/12 của kỳ chưa xét, tiến hành xét duyệt hạng cho toàn bộ khách hàng:
     * khách có điểm dưới mức duy trì sẽ bị giáng cấp. Mỗi kỳ chỉ xét một lần.
     */
    private void xetDuyetHangNeuDenHan() {
        int namHienTai = java.time.LocalDate.now().getYear();
        int namDaXet = namHienTai - 1;
        File f = new File(FILE_XET_DUYET);
        if (f.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(f, StandardCharsets.UTF_8))) {
                String dong = br.readLine();
                if (dong != null && !dong.trim().isEmpty()) {
                    namDaXet = Integer.parseInt(dong.trim());
                }
            } catch (IOException | NumberFormatException e) {
                System.out.println(">>> File " + FILE_XET_DUYET + " không hợp lệ, bỏ qua kỳ xét duyệt cũ.");
            }
        }
        KhachHang.setNamXetDuyetGanNhat(namDaXet);

        // Kỳ 31/12/(namDaXet + 1) đã qua khi năm hiện tại lớn hơn năm đó
        if (namDaXet + 1 < namHienTai) {
            int soKhachDoiHang = 0;
            for (int i = 0; i < danhSach.size(); i++) {
                KhachHang kh = danhSach.get(i);
                if (kh.xetDuyetHang()) {
                    soKhachDoiHang++;
                    // Khách VIP bị giáng hạng thì chuyển thành đối tượng KhachHangThuong cho đúng loại
                    if (kh instanceof KhachHangVip && kh.getCapHang() < KhachHang.CAP_VIP) {
                        KhachHang.demKH--;
                        KhachHangThuong khThuong = new KhachHangThuong(kh.getMaKH(), kh.getTenKH(),
                                kh.getSoDienThoai(), kh.getDiaChi(), kh.getDiemTichLuy());
                        khThuong.setCapHang(kh.getCapHang());
                        danhSach.set(i, khThuong);
                    }
                }
            }
            KhachHang.setNamXetDuyetGanNhat(namHienTai - 1);
            System.out.println(">>> Đã xét duyệt hạng thành viên kỳ 31/12/" + (namHienTai - 1)
                    + ": " + soKhachDoiHang + " khách hàng thay đổi hạng.");
            ghiTệp(FILE_MAC_DINH);
        }

        if (!f.exists() || KhachHang.getNamXetDuyetGanNhat() != namDaXet) {
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(f, StandardCharsets.UTF_8))) {
                bw.write(String.valueOf(KhachHang.getNamXetDuyetGanNhat()));
                bw.newLine();
            } catch (IOException e) {
                System.out.println(">>> Lỗi khi ghi file " + FILE_XET_DUYET + ": " + e.getMessage());
            }
        }
    }

    /**
     * Tự động kiểm tra và nạp lại file nếu file khachhang.txt bị chỉnh sửa từ bên ngoài
     */
    public void kiemTraVaNapLai() {
        File file = new File(FILE_MAC_DINH);
        if (file.exists() && file.lastModified() > thoiGianDocFile) {
            System.out.println(">>> Phát hiện file " + FILE_MAC_DINH + " vừa có thay đổi từ bên ngoài, đang tự động đồng bộ lại...");
            đọcTệp(FILE_MAC_DINH);
        }
    }

    public void setScanner(Scanner sc) {
        if (sc != null) this.sc = sc;
    }

    public ArrayList<KhachHang> getDanhSach() {
        kiemTraVaNapLai();
        return danhSach;
    }

    public void themKhachHang(KhachHang kh) {
        if (kh != null) {
            danhSach.add(kh);
            ghiTệp(FILE_MAC_DINH);
        }
    }

    // ==================== THÊM KHÁCH HÀNG ====================
    @Override
    public void thêm() {
        System.out.println("\n===== THÊM KHÁCH HÀNG MỚI =====");
        int loai = 0;
        do {
            System.out.println("Chọn hạng khách hàng ban đầu:");
            System.out.println("  1. Khách hàng Chuẩn (Thường)");
            System.out.println("  2. Khách hàng VIP");
            System.out.print("Nhập lựa chọn của bạn: ");
            try {
                loai = Integer.parseInt(sc.nextLine().trim());
                if (loai == 1 || loai == 2) break;
                System.out.println(">>> Lựa chọn không hợp lệ! Vui lòng chỉ chọn 1 hoặc 2.");
            } catch (NumberFormatException e) {
                System.out.println(">>> Vui lòng nhập số 1 hoặc 2!");
            }
        } while (true);

        String maKH = "";
        do {
            System.out.print("Nhập mã khách hàng : ");
            maKH = sc.nextLine().trim();
            if (maKH.isEmpty()) {
                System.out.println(">>> Lỗi: Mã khách hàng không được để trống!");
                continue;
            }
            if (maKH.contains("|")) {
                System.out.println(">>> Lỗi: Mã khách hàng không được chứa ký tự '|'!");
                continue;
            }
            if (timTheoMa(maKH) != null) {
                System.out.println(">>> Mã khách hàng đã tồn tại! Vui lòng nhập mã khác.");
                return;
            }
            break;
        } while (true);

        String tenKH = "";
        do {
            System.out.print("Nhập tên khách hàng: ");
            tenKH = sc.nextLine().trim().replace("|", "-");
            if (tenKH.isEmpty()) {
                System.out.println(">>> Lỗi: Tên khách hàng không được để trống!");
                continue;
            }
            break;
        } while (true);

        String soDienThoai;
        do {
            System.out.print("Nhập số điện thoại (đúng 10 chữ số): ");
            soDienThoai = sc.nextLine().trim();
            if (!KhachHang.soDienThoaiHopLe(soDienThoai)) {
                System.out.println(">>> Số điện thoại không hợp lệ. Vui lòng nhập đúng 10 chữ số (bắt đầu bằng 0).");
                continue;
            }
            KhachHang daCo = timTheoSDT(soDienThoai);
            if (daCo != null) {
                System.out.printf(">>> Lỗi: Số điện thoại này đã được đăng ký bởi khách hàng: %s (%s)! Vui lòng nhập số khác.%n",
                        daCo.getTenKH(), daCo.getMaKH());
                continue;
            }
            break;
        } while (true);

        System.out.print("Nhập địa chỉ       : ");
        String diaChi = sc.nextLine().trim().replace("|", "-");
        if (diaChi.isEmpty()) diaChi = "Chưa cập nhật";

        if (loai == 1) {
            KhachHangThuong kht = new KhachHangThuong(maKH, tenKH, soDienThoai, diaChi, 0);
            danhSach.add(kht);
            System.out.println(">>> Thêm khách hàng Chuẩn thành công!");
            ghiTệp(FILE_MAC_DINH);
        } else if (loai == 2) {
            // Khách VIP được cấp thẳng Hạng Vàng (VIP), bắt đầu với 0 điểm
            KhachHangVip khv = new KhachHangVip(maKH, tenKH, soDienThoai, diaChi, 0);
            danhSach.add(khv);
            System.out.println(">>> Thêm khách hàng VIP (Hạng Vàng) thành công!");
            ghiTệp(FILE_MAC_DINH);
        }
    }

    // ==================== SỬA KHÁCH HÀNG ====================
    @Override
    public void sửa() {
        System.out.println("\n===== SỬA THÔNG TIN KHÁCH HÀNG =====");
        System.out.print("Nhập mã khách hàng cần sửa: ");
        String maKH = sc.nextLine().trim();

        KhachHang kh = timTheoMa(maKH);
        if (kh == null) {
            System.out.println(">>> Không tìm thấy khách hàng có mã: " + maKH);
            return;
        }

        System.out.println("--- Thông tin hiện tại ---");
        kh.hienThongTin();

        System.out.print("Nhập tên mới (bấm Enter để giữ nguyên): ");
        String tenMoi = sc.nextLine().trim().replace("|", "-");
        if (!tenMoi.isEmpty()) kh.setTenKH(tenMoi);

        String sdtMoi;
        do {
            System.out.print("Nhập SĐT mới (đúng 10 chữ số, Enter để giữ nguyên): ");
            sdtMoi = sc.nextLine().trim();
            if (sdtMoi.isEmpty()) break;
            if (!KhachHang.soDienThoaiHopLe(sdtMoi)) {
                System.out.println(">>> Số điện thoại không hợp lệ. Vui lòng nhập đúng 10 chữ số.");
                continue;
            }
            KhachHang daCo = timTheoSDT(sdtMoi);
            if (daCo != null && !daCo.getMaKH().equalsIgnoreCase(kh.getMaKH())) {
                System.out.printf(">>> Lỗi: Số điện thoại này đã được đăng ký bởi khách hàng: %s (%s)! Vui lòng nhập số khác.%n",
                        daCo.getTenKH(), daCo.getMaKH());
                continue;
            }
            kh.setSoDienThoai(sdtMoi);
            break;
        } while (true);

        System.out.print("Nhập địa chỉ mới (bấm Enter để giữ nguyên): ");
        String dcMoi = sc.nextLine().trim().replace("|", "-");
        if (!dcMoi.isEmpty()) kh.setDiaChi(dcMoi);

        System.out.println(">>> Cập nhật thông tin thành công!");
        ghiTệp(FILE_MAC_DINH);
    }

    // ==================== XÓA KHÁCH HÀNG ====================
    @Override
    public void xóa() {
        System.out.println("\n===== XÓA KHÁCH HÀNG =====");
        System.out.print("Nhập mã khách hàng cần xóa: ");
        String maKH = sc.nextLine().trim();

        KhachHang kh = timTheoMa(maKH);
        if (kh == null) {
            System.out.println(">>> Không tìm thấy khách hàng có mã: " + maKH);
            return;
        }

        System.out.println("--- Thông tin khách hàng sẽ bị xóa ---");
        kh.hienThongTin();

        System.out.print("Bạn có chắc chắn muốn xóa? (c/k): ");
        String xacNhan = sc.nextLine().trim().toLowerCase();
        if (xacNhan.equals("c") || xacNhan.equals("y")) {
            danhSach.remove(kh);
            KhachHang.demKH--;
            System.out.println(">>> Xóa khách hàng thành công!");
            ghiTệp(FILE_MAC_DINH);
        } else {
            System.out.println(">>> Hủy thao tác xóa.");
        }
    }

    // ==================== TÌM KIẾM ====================
    @Override
    public void tìmKiếm() {
        kiemTraVaNapLai();
        System.out.println("\n===== TÌM KIẾM KHÁCH HÀNG =====");
        System.out.println("  1. Tìm theo mã khách hàng");
        System.out.println("  2. Tìm theo tên khách hàng");
        System.out.println("  3. Tìm theo số điện thoại");
        System.out.print("Nhập lựa chọn của bạn: ");
        int luaChon = 0;
        try {
            luaChon = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println(">>> Lựa chọn không hợp lệ!");
            return;
        }

        if (luaChon == 1) {
            System.out.print("Nhập mã khách hàng cần tìm: ");
            String maKH = sc.nextLine().trim();
            KhachHang kh = timTheoMa(maKH);
            if (kh != null) {
                System.out.println(">>> Tìm thấy:");
                kh.hienThongTin();
            } else {
                System.out.println(">>> Không tìm thấy khách hàng có mã: " + maKH);
            }
        } else if (luaChon == 2) {
            System.out.print("Nhập tên khách hàng cần tìm: ");
            String tenKH = sc.nextLine().trim().toLowerCase();
            boolean timThay = false;
            for (KhachHang kh : danhSach) {
                if (kh.getTenKH().toLowerCase().contains(tenKH)) {
                    kh.hienThongTin();
                    timThay = true;
                }
            }
            if (!timThay) {
                System.out.println(">>> Không tìm thấy khách hàng có tên chứa: " + tenKH);
            }
        } else if (luaChon == 3) {
            System.out.print("Nhập số điện thoại cần tìm: ");
            String sdt = sc.nextLine().trim();
            KhachHang kh = timTheoSDT(sdt);
            if (kh != null) {
                System.out.println(">>> Tìm thấy:");
                kh.hienThongTin();
            } else {
                System.out.println(">>> Không tìm thấy khách hàng có SĐT: " + sdt);
            }
        } else {
            System.out.println(">>> Lựa chọn không hợp lệ!");
        }
    }

    // ==================== HIỂN THỊ ====================
    @Override
    public void hiểnThịDanhSách() {
        kiemTraVaNapLai();
        System.out.println("\n===== DANH SÁCH KHÁCH HÀNG =====");
        if (danhSach.isEmpty()) {
            System.out.println("  (Danh sách trống)");
            return;
        }
        System.out.println("+----------+------------------------+---------------+------------------------+------------------+-----------+");
        System.out.printf("| %-8s | %-22s | %-13s | %-22s | %-16s | %-9s |%n",
                "Mã KH", "Tên khách hàng", "Số điện thoại", "Địa chỉ", "Hạng thành viên", "Điểm TL");
        System.out.println("+----------+------------------------+---------------+------------------------+------------------+-----------+");
        for (KhachHang kh : danhSach) {
            double diem = kh.getDiemTichLuy();
            System.out.printf("| %-8s | %-22s | %-13s | %-22s | %-16s | %,9.0f |%n",
                    kh.getMaKH(),
                    kh.getTenKH(),
                    kh.getSoDienThoai(),
                    kh.getDiaChi(),
                    kh.getHangThanhVien(),
                    diem);
        }
        System.out.println("+----------+------------------------+---------------+------------------------+------------------+-----------+");
        KhachHang.inTongSo();
    }

    // ==================== ĐỌC FILE ====================
    @Override
    public void đọcTệp(String tênTệp) {
        File f = new File(tênTệp);
        if (!f.exists()) {
            System.out.println(">>> Không tìm thấy file: " + tênTệp);
            return;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(f, StandardCharsets.UTF_8))) {
            String dong;
            int demDoc = 0;
            danhSach.clear();
            KhachHang.demKH = 0;

            while ((dong = br.readLine()) != null) {
                dong = dong.trim();
                if (dong.isEmpty()) continue;

                String[] phan = dong.split("\\|");
                if (phan.length < 6) {
                    System.out.println(">>> Bỏ qua dòng thiếu dữ liệu: " + dong);
                    continue;
                }

                // Mỗi dòng xử lý riêng: dòng lỗi chỉ bị bỏ qua, không làm mất các khách hàng khác
                try {
                    String maKH = phan[0].trim();
                    String tenKH = phan[1].trim();
                    String sdt = phan[2].trim();
                    String diaChi = phan[3].trim();
                    String hangLuu = phan[4].trim();
                    double diem = Double.parseDouble(phan[5].trim());

                    KhachHang kh = new KhachHangThuong(maKH, tenKH, sdt, diaChi, diem);
                    kh.setHangThanhVien(hangLuu);
                    if (kh.getCapHang() == KhachHang.CAP_VIP) {
                        // Hạng Vàng (VIP) được nạp thành đối tượng KhachHangVip
                        KhachHang.demKH--;
                        kh = new KhachHangVip(maKH, tenKH, sdt, diaChi, diem);
                    }
                    danhSach.add(kh);
                    demDoc++;
                } catch (IllegalArgumentException e) {
                    // Bao gồm cả NumberFormatException (điểm sai) và số điện thoại sai định dạng
                    System.out.println(">>> Bỏ qua dòng lỗi dữ liệu: " + dong + " (" + e.getMessage() + ")");
                }
            }
            thoiGianDocFile = f.lastModified();
            System.out.println(">>> Tự động nạp được " + demDoc + " khách hàng từ file: " + tênTệp);
        } catch (IOException e) {
            System.out.println(">>> Lỗi khi đọc file: " + e.getMessage());
        }
    }

    // ==================== GHI FILE ====================
    @Override
    public void ghiTệp(String tênTệp) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(tênTệp, StandardCharsets.UTF_8))) {
            for (KhachHang kh : danhSach) {
                double diem = kh.getDiemTichLuy();
                // Format: maKH|tenKH|sdt|diaChi|hangThanhVien|diem
                bw.write(kh.getMaKH() + "|"
                        + kh.getTenKH() + "|"
                        + kh.getSoDienThoai() + "|"
                        + kh.getDiaChi() + "|"
                        + kh.getLoaiKH() + "|"
                        + diem);
                bw.newLine();
            }
            thoiGianDocFile = new File(tênTệp).lastModified();
            System.out.println(">>> Tự động cập nhật file: " + tênTệp);
        } catch (IOException e) {
            System.out.println(">>> Lỗi khi ghi file: " + e.getMessage());
        }
    }

    // ==================== HELPER: TÌM THEO MÃ ====================
    public KhachHang timTheoMa(String maKH) {
        kiemTraVaNapLai();
        if (maKH == null) return null;
        for (KhachHang kh : danhSach) {
            if (kh.getMaKH().equalsIgnoreCase(maKH.trim())) {
                return kh;
            }
        }
        return null;
    }

    // ==================== HELPER: TÌM THEO SĐT ====================
    public KhachHang timTheoSDT(String sdt) {
        kiemTraVaNapLai();
        if (sdt == null) return null;
        for (KhachHang kh : danhSach) {
            if (kh.getSoDienThoai() != null && kh.getSoDienThoai().equals(sdt.trim())) {
                return kh;
            }
        }
        return null;
    }

    // ==================== MENU CHÍNH ====================
    public void hienMenu() {
        hienMenu(this.sc);
    }

    public void hienMenu(Scanner sc) {
        this.sc = sc;
        kiemTraVaNapLai();
        int luaChon = -1;
        do {
            System.out.println("\n╔══════════════════════════════════╗");
            System.out.println("║     QUẢN LÝ KHÁCH HÀNG           ║");
            System.out.println("╠══════════════════════════════════╣");
            System.out.println("║  1. Thêm khách hàng              ║");
            System.out.println("║  2. Sửa thông tin khách hàng     ║");
            System.out.println("║  3. Xóa khách hàng               ║");
            System.out.println("║  4. Tìm kiếm khách hàng          ║");
            System.out.println("║  5. Hiển thị danh sách           ║");
            System.out.println("║  6. Đọc dữ liệu từ file          ║");
            System.out.println("║  7. Ghi dữ liệu ra file          ║");
            System.out.println("║  0. Quay lại menu trước          ║");
            System.out.println("╚══════════════════════════════════╝");
            System.out.print("Nhập lựa chọn của bạn: ");

            try {
                luaChon = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println(">>> Vui lòng nhập số!");
                continue;
            }

            switch (luaChon) {
                case 1: thêm(); break;
                case 2: sửa(); break;
                case 3: xóa(); break;
                case 4: tìmKiếm(); break;
                case 5: hiểnThịDanhSách(); break;
                case 6:
                    System.out.print("Nhập tên file cần đọc: ");
                    String fileDoc = sc.nextLine().trim();
                    đọcTệp(fileDoc);
                    break;
                case 7:
                    System.out.print("Nhập tên file cần ghi: ");
                    String fileGhi = sc.nextLine().trim();
                    ghiTệp(fileGhi);
                    break;
                case 0:
                    break;
                default:
                    System.out.println(">>> Lựa chọn không hợp lệ! Vui lòng chọn từ 0-7.");
            }
        } while (luaChon != 0);
    }
}
