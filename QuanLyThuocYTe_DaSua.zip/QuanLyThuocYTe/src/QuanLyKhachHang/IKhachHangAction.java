package QuanLyKhachHang;

public interface IKhachHangAction {
    void thêm();
    void sửa();
    void xóa();
    void tìmKiếm();
    void hiểnThịDanhSách();
    void đọcTệp(String tênTệp);
    void ghiTệp(String tênTệp);
}
