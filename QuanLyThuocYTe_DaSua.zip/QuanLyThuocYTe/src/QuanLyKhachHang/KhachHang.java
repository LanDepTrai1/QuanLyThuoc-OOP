package QuanLyKhachHang;

import java.time.LocalDate;

public abstract class KhachHang {
    private String maKH;
    private String tenKH;
    private String soDienThoai;
    private String diaChi;
    // Cấp hạng hiện tại: 0 = Hạng Chuẩn, 1 = Hạng Bạc, 2 = Hạng Vàng (VIP)
    private int capHang;
    private double diemTichLuy;

    // Bảng quy định hạng thành viên (dùng chung cho mọi khách hàng)
    public static final String[] TEN_HANG = {"Hạng Chuẩn", "Hạng Bạc", "Hạng Vàng (VIP)"};
    public static final double[] DIEM_HANG = {0, 1000, 3000};
    public static final double[] GIAM_GIA_HANG = {0.0, 0.02, 0.05};
    public static final int CAP_VIP = 2;

    // Năm gần nhất đã thực hiện xét duyệt hạng (kỳ xét duyệt chung là ngày 31/12 mỗi năm)
    private static int namXetDuyetGanNhat = LocalDate.now().getYear() - 1;

    public static int demKH = 0;

    // Constructor mặc định
    public KhachHang() {
        this.capHang = 0;
    }

    // Constructor có tham số
    public KhachHang(String maKH, String tenKH, String soDienThoai, String diaChi, double diemTichLuy) {
        this.maKH = maKH;
        this.tenKH = tenKH;
        this.setSoDienThoai(soDienThoai);
        this.diaChi = diaChi;
        this.diemTichLuy = diemTichLuy < 0 ? 0 : diemTichLuy;
        this.capHang = tinhCapTheoDiem(this.diemTichLuy);
    }

    public static boolean soDienThoaiHopLe(String soDienThoai) {
        return soDienThoai != null && soDienThoai.trim().matches("0[0-9]{9}");
    }

    public static void inTongSo() {
        System.out.println("Tổng số khách hàng: " + demKH);
    }

    // ==================== HẠNG THÀNH VIÊN ====================

    /** Cấp hạng tương ứng với một số điểm */
    public static int tinhCapTheoDiem(double diem) {
        if (diem >= DIEM_HANG[2]) return 2;
        if (diem >= DIEM_HANG[1]) return 1;
        return 0;
    }

    /**
     * Lên hạng ngay khi điểm đạt mốc của hạng cao hơn.
     * Không tự hạ hạng ở đây: việc hạ hạng chỉ diễn ra ở kỳ xét duyệt (xem xetDuyetHang()).
     */
    public void capNhatHang() {
        int capTheoDiem = tinhCapTheoDiem(diemTichLuy);
        if (capTheoDiem > capHang) {
            capHang = capTheoDiem;
        }
    }

    /**
     * Xét duyệt hạng vào kỳ chung 31/12: nếu điểm dưới mức duy trì của hạng hiện tại
     * thì giáng xuống hạng tương ứng với số điểm đang có.
     * @return true nếu hạng bị thay đổi
     */
    public boolean xetDuyetHang() {
        int capMoi = tinhCapTheoDiem(diemTichLuy);
        if (capMoi != capHang) {
            capHang = capMoi;
            return true;
        }
        return false;
    }

    /** Tên Hạng thành viên tiếp theo */
    public String getHangTiepTheo() {
        if (capHang >= CAP_VIP) {
            return "Đã đạt hạng cao nhất";
        }
        return TEN_HANG[capHang + 1];
    }

    /** Số điểm cần tích lũy thêm để lên hạng tiếp theo */
    public double getDiemCanLênHang() {
        if (capHang >= CAP_VIP) {
            return 0;
        }
        double canThem = DIEM_HANG[capHang + 1] - diemTichLuy;
        return canThem > 0 ? canThem : 0;
    }

    /** Số tiền cần chi tiêu thêm để lên hạng tiếp theo (1.000 VNĐ chi tiêu = 1 điểm) */
    public double getSoTienChiTieuThem() {
        return getDiemCanLênHang() * 1000.0;
    }

    /** Mức điểm tối thiểu để giữ hạng hiện tại khi đến kỳ xét duyệt */
    public double getDiemDuyTriHang() {
        return DIEM_HANG[capHang];
    }

    /** Tỷ lệ chiết khấu giảm giá trực tiếp theo hạng thành viên */
    public double getMucGiamGia() {
        return GIAM_GIA_HANG[capHang];
    }

    // ==================== KỲ XÉT DUYỆT CHUNG ====================

    /** Ngày xét duyệt hạng sắp tới: 31/12 của năm kế tiếp năm đã xét gần nhất */
    public static String getNgayXetDuyetTiepTheo() {
        return "31/12/" + (namXetDuyetGanNhat + 1);
    }

    public static int getNamXetDuyetGanNhat() {
        return namXetDuyetGanNhat;
    }

    public static void setNamXetDuyetGanNhat(int nam) {
        namXetDuyetGanNhat = nam;
    }

    // Getter và Setter
    public String getMaKH() {
        return maKH;
    }

    public void setMaKH(String maKH) {
        this.maKH = maKH;
    }

    public String getTenKH() {
        return tenKH;
    }

    public void setTenKH(String tenKH) {
        this.tenKH = tenKH;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(String soDienThoai) {
        if (!soDienThoaiHopLe(soDienThoai)) {
            throw new IllegalArgumentException("Số điện thoại phải gồm đúng 10 chữ số.");
        }
        this.soDienThoai = soDienThoai.trim();
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public int getCapHang() {
        return capHang;
    }

    public void setCapHang(int capHang) {
        if (capHang < 0) capHang = 0;
        if (capHang > CAP_VIP) capHang = CAP_VIP;
        this.capHang = capHang;
    }

    public String getHangThanhVien() {
        return TEN_HANG[capHang];
    }

    /**
     * Đặt hạng theo tên đã lưu trong file (ví dụ "Hạng Bạc").
     * Hỗ trợ cả dữ liệu cũ ghi "Thuong" / "VIP".
     */
    public void setHangThanhVien(String hangThanhVien) {
        if (hangThanhVien == null) return;
        String s = hangThanhVien.trim();
        for (int i = 0; i < TEN_HANG.length; i++) {
            if (TEN_HANG[i].equalsIgnoreCase(s)) {
                capHang = i;
                return;
            }
        }
        if (s.toUpperCase().contains("VIP") || s.toLowerCase().contains("vàng")) {
            capHang = CAP_VIP;
        } else if (s.toLowerCase().contains("bạc")) {
            capHang = 1;
        } else {
            capHang = tinhCapTheoDiem(diemTichLuy);
        }
    }

    // Giữ tương thích ngược với getLoaiKH()
    public String getLoaiKH() {
        return getHangThanhVien();
    }

    public void setLoaiKH(String loaiKH) {
        setHangThanhVien(loaiKH);
    }

    public double getDiemTichLuy() {
        return diemTichLuy;
    }

    /** Cập nhật điểm; chỉ có thể làm lên hạng, không làm tụt hạng (tụt hạng chỉ xảy ra khi xét duyệt) */
    public void setDiemTichLuy(double diemTichLuy) {
        this.diemTichLuy = diemTichLuy < 0 ? 0 : diemTichLuy;
        capNhatHang();
    }

    /**
     * Công thức tích điểm: Mỗi 1.000 VNĐ chi tiêu = 1 điểm thưởng
     */
    public double tinhDiem(double tongTien) {
        if (tongTien <= 0) return 0;
        return (long) (tongTien / 1000.0);
    }

    /** In phần thông tin hạng thành viên (dùng chung cho các lớp con) */
    protected void inThongTinHang() {
        System.out.printf("Hạng thành viên             : %s%n", getHangThanhVien());
        System.out.printf("Điểm tích lũy               : %,.0f điểm%n", getDiemTichLuy());
        System.out.printf("Mức ưu đãi giảm giá         : %.0f%%%n", getMucGiamGia() * 100);
        System.out.printf("Hạng tiếp theo              : %s%n", getHangTiepTheo());
        if (capHang < CAP_VIP) {
            System.out.printf("Chi tiêu thêm để lên hạng   : %,.0f VNĐ (Cần thêm %,.0f điểm)%n",
                    getSoTienChiTieuThem(), getDiemCanLênHang());
        } else {
            System.out.println("Chi tiêu thêm để lên hạng   : Đã đạt hạng cao nhất!");
        }
        System.out.printf("Thời hạn xét duyệt hạng     : %s%n", getNgayXetDuyetTiepTheo());
        System.out.printf("Điểm duy trì hạng tối thiểu : %,.0f điểm (Đến kỳ xét duyệt mà dưới mức này sẽ bị giáng cấp)%n",
                getDiemDuyTriHang());
    }

    // Phương thức hiển thị thông tin
    public abstract void hienThongTin();
}
