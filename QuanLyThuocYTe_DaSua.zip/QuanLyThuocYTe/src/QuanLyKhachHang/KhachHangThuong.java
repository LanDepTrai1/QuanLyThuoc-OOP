package QuanLyKhachHang;

public class KhachHangThuong extends KhachHang {

    public KhachHangThuong() {
        super();
        demKH++;
    }

    public KhachHangThuong(String maKH, String tenKH, String soDienThoai, String diaChi, double diemTichLuy) {
        super(maKH, tenKH, soDienThoai, diaChi, diemTichLuy);
        demKH++;
    }

    @Override
    public void hienThongTin() {
        System.out.println("----------------------------------------------------------------------");
        System.out.printf("Mã khách hàng               : %s%n", getMaKH());
        System.out.printf("Tên khách hàng              : %s%n", getTenKH());
        System.out.printf("Số điện thoại               : %s%n", getSoDienThoai());
        System.out.printf("Địa chỉ                     : %s%n", getDiaChi());
        inThongTinHang();
        System.out.println("----------------------------------------------------------------------");
    }
}
