package QuanLyHoaDon;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import QuanLyThuoc.QuanLyThuoc;
import QuanLyThuoc.Thuoc;
import QuanLyThuoc.ThuocKeDon;
import QuanLyKhachHang.QuanLyKhachHang;
import QuanLyKhachHang.KhachHang;
import QuanLyKhachHang.KhachHangThuong;
import QuanLyKhachHang.KhachHangVip;
import QuanLyNhanVien.QuanLyNhanVien;
import QuanLyNhanVien.NhanVien;
import QuanLyNhanVien.NhanVienBanHang;

public class QuanLyHoaDon implements IHoaDonAction {
    // Tên file mặc định
    private static final String FILE_MAC_DINH = "hoadon.txt";

    // Danh sách hóa đơn
    private ArrayList<HoaDon> danhSach;
    // Scanner nhập liệu
    private Scanner sc;
    // Thời điểm sửa đổi file lần cuối được nạp
    private long thoiGianDocFile = 0;

    // Constructor
    public QuanLyHoaDon() {
        danhSach = new ArrayList<>();
        sc = new Scanner(System.in);
        File file = new File(FILE_MAC_DINH);
        if (file.exists()) {
            docFile(FILE_MAC_DINH);
        }
    }

    /**
     * Tự động kiểm tra và nạp lại file nếu file hoadon.txt bị chỉnh sửa từ bên ngoài
     */
    public void kiemTraVaNapLai() {
        File file = new File(FILE_MAC_DINH);
        if (file.exists() && file.lastModified() > thoiGianDocFile) {
            System.out.println(">>> Phát hiện file " + FILE_MAC_DINH + " vừa có thay đổi từ bên ngoài, đang tự động đồng bộ lại...");
            docFile(FILE_MAC_DINH);
        }
    }

    public ArrayList<HoaDon> getDanhSach() {
        kiemTraVaNapLai();
        return danhSach;
    }

    public void setScanner(Scanner sc) {
        if (sc != null) this.sc = sc;
    }

    @Override
    public void taoHoaDon() {
        taoHoaDon(this.sc, null, null, null, null);
    }

    /**
     * Tạo hóa đơn liên kết với Thuốc, Khách hàng và Nhân viên
     * @param sc Scanner nhập liệu từ Main
     * @param maNVDangNhap Mã nhân viên đang đăng nhập (nếu là nhân viên bán hàng)
     */
    public void taoHoaDon(Scanner sc, String maNVDangNhap, QuanLyThuoc qlThuoc, QuanLyKhachHang qlKhachHang, QuanLyNhanVien qlNhanVien) {
        if (sc != null) {
            this.sc = sc;
        }
        System.out.println("\n===== TẠO HÓA ĐƠN BÁN HÀNG MỚI =====");

        // 1. Mã hóa đơn (ràng buộc không được để trống và không trùng)
        String maHD = "";
        do {
            System.out.print("Nhập mã hóa đơn: ");
            maHD = sc.nextLine().trim();
            if (maHD.isEmpty()) {
                System.out.println(">>> Lỗi: Mã hóa đơn không được để trống! Vui lòng nhập lại.");
                continue;
            }
            if (maHD.contains("|")) {
                System.out.println(">>> Lỗi: Mã hóa đơn không được chứa ký tự '|'! Vui lòng nhập lại.");
                continue;
            }
            boolean trung = false;
            for (HoaDon hd : danhSach) {
                if (hd.getMaHD().equalsIgnoreCase(maHD)) {
                    System.out.println(">>> Lỗi: Mã hóa đơn đã tồn tại! Vui lòng nhập mã khác.");
                    trung = true;
                    break;
                }
            }
            if (!trung) break;
        } while (true);

        // 2. Ngày lập: Tự động cập nhật ngày hiện tại
        String ngayLap = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        System.out.println("Ngày tạo hóa đơn: " + ngayLap + " (Tự động cập nhật)");

        // 3. Mã nhân viên bán hàng
        String maNV = maNVDangNhap;
        if (maNV == null || maNV.isEmpty()) {
            do {
                System.out.print("Nhập mã nhân viên bán hàng: ");
                maNV = sc.nextLine().trim();
                if (maNV.isEmpty()) {
                    System.out.println(">>> Lỗi: Mã nhân viên không được để trống!");
                    continue;
                }
                if (qlNhanVien != null) {
                    NhanVien nvNhap = qlNhanVien.timTheoMa(maNV);
                    if (nvNhap == null) {
                        System.out.println(">>> Lỗi: Mã nhân viên [" + maNV + "] không có trong danh sách nhân viên! Vui lòng nhập lại.");
                        continue;
                    }
                    if (!(nvNhap instanceof NhanVienBanHang)) {
                        System.out.println(">>> Lỗi: [" + maNV + "] không phải nhân viên bán hàng! Vui lòng nhập mã nhân viên bán hàng.");
                        continue;
                    }
                    maNV = nvNhap.getMaNV();
                }
                break;
            } while (true);
        } else {
            System.out.println("Nhân viên phụ trách: " + maNV);
        }

        // 4. Khách hàng & Số điện thoại
        String maKH = "";
        String tenKH = "";
        String soDienThoai = "";
        KhachHang khachHangHienTai = null;
        // Khách hàng mới chỉ được lưu vào file khi hóa đơn hoàn tất (hủy hóa đơn thì không lưu)
        boolean laKhachHangMoi = false;

        do {
            System.out.print("Nhập số điện thoại khách hàng (bấm Enter nếu khách vãng lai): ");
            soDienThoai = sc.nextLine().trim();

            if (soDienThoai.isEmpty()) {
                // Khách lẻ vãng lai
                maKH = "KH_VL";
                tenKH = "Khách vãng lai";
                System.out.println(">> Khách hàng không cung cấp SĐT (Gán: Khách vãng lai - " + maKH + ")");
                break;
            }

            if (!KhachHang.soDienThoaiHopLe(soDienThoai)) {
                System.out.println(">>> Lỗi: Số điện thoại không hợp lệ! Vui lòng nhập đúng 10 chữ số (bắt đầu bằng 0) hoặc bấm Enter để bỏ qua.");
                continue;
            }

            // Tìm theo số điện thoại
            if (qlKhachHang != null) {
                khachHangHienTai = qlKhachHang.timTheoSDT(soDienThoai);
            }

            if (khachHangHienTai != null) {
                // Đã có trong hệ thống
                maKH = khachHangHienTai.getMaKH();
                tenKH = khachHangHienTai.getTenKH();
                System.out.printf("[✓] Đã tìm thấy khách hàng: %s (%s) - %s - Điểm tích lũy: %,.0f điểm%n",
                        tenKH, maKH, khachHangHienTai.getHangThanhVien(), khachHangHienTai.getDiemTichLuy());
            } else {
                // Chưa có trong file khachhang.txt -> Thêm khách hàng mới
                System.out.println(">> Số điện thoại chưa có trong file khachhang.txt.");
                System.out.println(">> Tiến hành thêm khách hàng mới để tích lũy điểm cho các lần mua sau:");

                do {
                    System.out.print("  Nhập tên khách hàng: ");
                    tenKH = sc.nextLine().trim().replace("|", "-");
                    if (tenKH.isEmpty()) {
                        System.out.println("  >>> Lỗi: Tên khách hàng không được để trống!");
                    }
                } while (tenKH.isEmpty());

                // Tự sinh mã khách hàng mới
                int count = (qlKhachHang != null) ? qlKhachHang.getDanhSach().size() + 1 : 1;
                maKH = String.format("KH%02d", count);
                if (qlKhachHang != null) {
                    while (qlKhachHang.timTheoMa(maKH) != null) {
                        count++;
                        maKH = String.format("KH%02d", count);
                    }
                }

                System.out.print("  Nhập địa chỉ khách hàng (Enter để bỏ qua): ");
                String diaChi = sc.nextLine().trim().replace("|", "-");
                if (diaChi.isEmpty()) diaChi = "Chưa cập nhật";

                // Tạo khách hàng thường mới với điểm ban đầu = 0 (lưu vào file khi hóa đơn hoàn tất)
                KhachHangThuong khMoi = new KhachHangThuong(maKH, tenKH, soDienThoai, diaChi, 0);
                khachHangHienTai = khMoi;
                laKhachHangMoi = true;
            }
            break;
        } while (true);

        // Tạo hóa đơn
        HoaDon hd = new HoaDon(maHD, maKH, tenKH, soDienThoai, maNV, ngayLap, 0);

        // 5. Thêm thuốc vào hóa đơn
        System.out.println("\n--- CHỌN THUỐC VÀO HÓA ĐƠN ---");
        // Số lượng đã chọn của từng thuốc trong hóa đơn này (chỉ trừ kho thật khi hóa đơn hoàn tất)
        Map<String, Integer> soLuongDaChon = new HashMap<>();
        String tiep = "c";
        while (tiep.equalsIgnoreCase("c")) {
            System.out.print("Nhập mã thuốc/vật tư cần mua ('x' để kết thúc, 'huy' để hủy hóa đơn): ");
            String maThuoc = sc.nextLine().trim();
            if (maThuoc.equalsIgnoreCase("huy")) {
                System.out.println(">>> Đã hủy hóa đơn " + maHD + ". Không có thay đổi nào được lưu.");
                return;
            }
            if (maThuoc.equalsIgnoreCase("x") || maThuoc.isEmpty()) {
                if (hd.getDanhSachMaThuoc().isEmpty()) {
                    System.out.print(">>> Hóa đơn chưa có thuốc nào. Bạn có muốn hủy hóa đơn này? (c = hủy / k = tiếp tục chọn thuốc): ");
                    String huy = sc.nextLine().trim();
                    if (huy.equalsIgnoreCase("c") || huy.equalsIgnoreCase("y")) {
                        System.out.println(">>> Đã hủy hóa đơn " + maHD + ". Không có thay đổi nào được lưu.");
                        return;
                    }
                    continue;
                }
                break;
            }

            Thuoc thuocTim = (qlThuoc != null) ? qlThuoc.timTheoMa(maThuoc) : null;
            if (thuocTim == null) {
                System.out.println("  [!] Không tìm thấy mã thuốc/vật tư trong kho! Vui lòng nhập đúng mã thuốc trong kho.");
                continue;
            }

            String khoaThuoc = thuocTim.getMaThuoc().toUpperCase();
            int tonKho = thuocTim.getSoLuong() - soLuongDaChon.getOrDefault(khoaThuoc, 0);
            if (tonKho <= 0) {
                System.out.println("  [!] Thuốc/vật tư này đã hết hàng trong kho (hoặc đã chọn hết số lượng còn lại)!");
                continue;
            }
            if (thuocTim.daHetHan()) {
                System.out.println("  [!] Thuốc/vật tư này đã hết hạn sử dụng (" + thuocTim.getHanSuDung()
                        + "), không được bán!");
                continue;
            }

            double gia = thuocTim.getGiaBan();
            System.out.printf("  -> Tên: %s | Giá: %,.0f VNĐ | Tồn kho: %d%n",
                    thuocTim.getTenThuoc(), gia, tonKho);

            // Kiểm tra thuốc kê đơn
            boolean laThuocKeDon = (thuocTim instanceof ThuocKeDon) || thuocTim.getMaThuoc().toUpperCase().startsWith("KD");
            if (laThuocKeDon) {
                System.out.println("  [!] CHÚ Ý: Đây là THUỐC KÊ ĐƠN, bắt buộc phải có thông tin toa thuốc!");
                System.out.print("  Nhập Bác sĩ kê đơn : ");
                String bacSi = sc.nextLine().trim().replace("|", "-");
                System.out.print("  Nhập Mã đơn thuốc   : ");
                String maDon = sc.nextLine().trim().replace("|", "-");

                if (bacSi.isEmpty() || maDon.isEmpty()) {
                    System.out.println("  [!] Không thể bán thuốc kê đơn khi thiếu Bác sĩ kê đơn hoặc Mã đơn thuốc! Đã hủy thêm thuốc này.");
                    continue;
                }
                hd.setBacSiKeDon(bacSi);
                hd.setMaDonThuoc(maDon);
            }

            int soLuong = 0;
            do {
                System.out.print("  Nhập số lượng mua: ");
                try {
                    soLuong = Integer.parseInt(sc.nextLine().trim());
                    if (soLuong <= 0) {
                        System.out.println("  >>> Số lượng phải lớn hơn 0!");
                        continue;
                    }
                    if (soLuong > tonKho) {
                        System.out.printf("  >>> Lỗi: Số lượng mua (%d) vượt quá tồn kho (%d)!%n", soLuong, tonKho);
                        continue;
                    }
                    break;
                } catch (NumberFormatException e) {
                    System.out.println("  >>> Số lượng không hợp lệ!");
                }
            } while (true);

            // Ghi nhận số lượng đã chọn; tồn kho thật chỉ bị trừ khi hóa đơn hoàn tất
            soLuongDaChon.put(khoaThuoc, soLuongDaChon.getOrDefault(khoaThuoc, 0) + soLuong);

            hd.themThuoc(thuocTim.getMaThuoc(), gia, soLuong);
            System.out.println("  [✓] Đã thêm vào hóa đơn.");

            System.out.print("Bạn có muốn thêm thuốc khác vào hóa đơn? (c = có / k = không): ");
            tiep = sc.nextLine().trim();
        }

        // 6. Tính giảm giá & Điểm tích lũy
        double tongTienGoc = hd.tinhTongTien();
        double giamGia = 0;

        if (khachHangHienTai != null) {
            double mucGiamGia = khachHangHienTai.getMucGiamGia();
            double giamGiaHang = 0;
            if (mucGiamGia > 0) {
                giamGiaHang = tongTienGoc * mucGiamGia;
                System.out.printf(">> Ưu đãi %s: Giảm %.0f%% (-%,.0f VNĐ)%n",
                        khachHangHienTai.getHangThanhVien(), mucGiamGia * 100, giamGiaHang);
            }

            double tongConLai = tongTienGoc - giamGiaHang;
            double giamGiaDiem = 0;

            if (khachHangHienTai.getDiemTichLuy() > 0 && tongConLai > 0) {
                System.out.printf("Khách hàng có %,.0f điểm tích lũy. Bạn có muốn đổi điểm để giảm giá? (1 điểm = 10 VNĐ) (c/k): ",
                        khachHangHienTai.getDiemTichLuy());
                String dungDiem = sc.nextLine().trim();
                if (dungDiem.equalsIgnoreCase("c") || dungDiem.equalsIgnoreCase("y")) {
                    double tienGiamToiDaTuDiem = khachHangHienTai.getDiemTichLuy() * 10.0;
                    if (tienGiamToiDaTuDiem >= tongConLai) {
                        giamGiaDiem = tongConLai;
                        double diemTru = Math.ceil(tongConLai / 10.0);
                        khachHangHienTai.setDiemTichLuy(khachHangHienTai.getDiemTichLuy() - diemTru);
                    } else {
                        giamGiaDiem = tienGiamToiDaTuDiem;
                        khachHangHienTai.setDiemTichLuy(0);
                    }
                    System.out.printf(">> Đã áp dụng giảm giá từ điểm tích lũy: -%,.0f VNĐ%n", giamGiaDiem);
                }
            }

            giamGia = giamGiaHang + giamGiaDiem;
        }

        hd.setGiamGia(giamGia);
        double thanhToan = hd.tinhThanhToan();

        // Hóa đơn hoàn tất: lúc này mới trừ tồn kho thật và ghi file thuốc một lần
        if (qlThuoc != null) {
            for (Map.Entry<String, Integer> muc : soLuongDaChon.entrySet()) {
                Thuoc t = qlThuoc.timTheoMa(muc.getKey());
                if (t != null) {
                    t.setSoLuong(t.getSoLuong() - muc.getValue());
                }
            }
            qlThuoc.ghiFile("thuoc.txt");
        }

        // Cộng điểm tích lũy mới cho khách hàng: 1.000 VNĐ chi tiêu = 1 điểm thưởng
        if (khachHangHienTai != null) {
            double diemCong = khachHangHienTai.tinhDiem(thanhToan);
            khachHangHienTai.setDiemTichLuy(khachHangHienTai.getDiemTichLuy() + diemCong);
            if (qlKhachHang != null) {
                if (laKhachHangMoi) {
                    // themKhachHang đã tự ghi file khachhang.txt
                    qlKhachHang.themKhachHang(khachHangHienTai);
                    System.out.println("[✓] Đã lưu thông tin khách hàng mới vào file khachhang.txt!");
                } else {
                    qlKhachHang.ghiTệp("khachhang.txt");
                }
            }
            System.out.printf("[✓] Đã cộng thêm %,.0f điểm tích lũy cho khách hàng %s (Hiện có: %,.0f điểm - %s).%n",
                    diemCong, tenKH, khachHangHienTai.getDiemTichLuy(), khachHangHienTai.getHangThanhVien());
        }

        // 7. Lưu hóa đơn vào danh sách và file
        danhSach.add(hd);
        ghiFile(FILE_MAC_DINH);

        // 8. Đồng bộ doanh số tháng cho nhân viên bán hàng
        if (qlNhanVien != null) {
            qlNhanVien.dongBoDoanhSoTuHoaDon(this);
            System.out.printf("[✓] Đã tự động cập nhật doanh số tháng của nhân viên %s từ hóa đơn.%n", maNV);
        }

        // 9. In hóa đơn hoàn chỉnh
        System.out.println("\n[✓] TẠO HÓA ĐƠN THÀNH CÔNG!");
        hd.hienThongTin();
    }

    // ==================== HIỂN THỊ DANH SÁCH ====================
    @Override
    public void hienDanhSach() {
        kiemTraVaNapLai();
        System.out.println("\n===== DANH SÁCH HÓA ĐƠN =====");
        if (danhSach.isEmpty()) {
            System.out.println("  (Chưa có hóa đơn nào)");
            return;
        }
        System.out.printf("%-4s %-10s %-10s %-20s %-10s %-12s %16s%n",
                "STT", "Mã HĐ", "Mã KH", "Tên KH", "Mã NV", "Ngày lập", "Thanh toán (VNĐ)");
        System.out.println("-".repeat(90));
        int stt = 1;
        for (HoaDon hd : danhSach) {
            System.out.printf("%-4d %-10s %-10s %-20s %-10s %-12s %,16.0f%n",
                    stt++,
                    hd.getMaHD(),
                    hd.getMaKH(),
                    hd.getTenKH(),
                    hd.getMaNV(),
                    hd.getNgayLap(),
                    hd.tinhThanhToan());
        }
        System.out.println("-".repeat(90));
        System.out.println("Tổng số hóa đơn: " + danhSach.size());
    }

    /**
     * Tính doanh số THÁNG HIỆN TẠI theo mã nhân viên bán hàng
     * (chỉ cộng các hóa đơn lập trong tháng/năm hiện tại, để hoa hồng không bị cộng dồn qua các tháng)
     */
    public double tinhTongDoanhSoTheoNV(String maNV) {
        kiemTraVaNapLai();
        if (maNV == null) return 0;
        double tong = 0;
        for (HoaDon hd : danhSach) {
            if (hd.getMaNV() != null && hd.getMaNV().equalsIgnoreCase(maNV.trim())
                    && laHoaDonThangNay(hd)) {
                tong += hd.tinhThanhToan();
            }
        }
        return tong;
    }

    /** Hóa đơn có ngày lập (dd/MM/yyyy) thuộc tháng và năm hiện tại hay không */
    private boolean laHoaDonThangNay(HoaDon hd) {
        String thangNay = LocalDate.now().format(DateTimeFormatter.ofPattern("MM/yyyy"));
        return hd.getNgayLap() != null && hd.getNgayLap().endsWith(thangNay);
    }

    /**
     * Hiển thị danh sách hóa đơn theo mã nhân viên
     */
    public void hienDanhSachTheoNV(String maNV) {
        kiemTraVaNapLai();
        System.out.println("\n===== DANH SÁCH HÓA ĐƠN CỦA NHÂN VIÊN: " + maNV + " =====");
        ArrayList<HoaDon> ketQua = new ArrayList<>();
        for (HoaDon hd : danhSach) {
            if (hd.getMaNV() != null && hd.getMaNV().equalsIgnoreCase(maNV)) {
                ketQua.add(hd);
            }
        }
        if (ketQua.isEmpty()) {
            System.out.println("  (Bạn chưa lập hóa đơn nào)");
            return;
        }
        System.out.printf("%-4s %-10s %-10s %-20s %-12s %16s%n",
                "STT", "Mã HĐ", "Mã KH", "Tên KH", "Ngày lập", "Thanh toán (VNĐ)");
        System.out.println("-".repeat(78));
        int stt = 1;
        double tongDoanhSo = 0;
        double doanhSoThangNay = 0;
        for (HoaDon hd : ketQua) {
            double tt = hd.tinhThanhToan();
            tongDoanhSo += tt;
            if (laHoaDonThangNay(hd)) {
                doanhSoThangNay += tt;
            }
            System.out.printf("%-4d %-10s %-10s %-20s %-12s %,16.0f%n",
                    stt++,
                    hd.getMaHD(),
                    hd.getMaKH(),
                    hd.getTenKH(),
                    hd.getNgayLap(),
                    tt);
        }
        System.out.println("-".repeat(78));
        System.out.printf("Tổng cộng: %d hóa đơn | Tổng doanh số: %,.0f VNĐ | Doanh số tháng %s: %,.0f VNĐ%n",
                ketQua.size(), tongDoanhSo,
                LocalDate.now().format(DateTimeFormatter.ofPattern("MM/yyyy")), doanhSoThangNay);
    }

    // ==================== TÌM KIẾM ====================
    @Override
    public void timKiem() {
        kiemTraVaNapLai();
        System.out.println("\n===== TÌM KIẾM HÓA ĐƠN =====");
        System.out.print("Nhập mã hóa đơn, mã khách hàng hoặc số điện thoại: ");
        String tuKhoa = sc.nextLine().trim();

        boolean timThay = false;
        for (HoaDon hd : danhSach) {
            if (hd.getMaHD().equalsIgnoreCase(tuKhoa) ||
                hd.getMaKH().equalsIgnoreCase(tuKhoa) ||
                hd.getSoDienThoai().equalsIgnoreCase(tuKhoa)) {
                hd.hienThongTin();
                timThay = true;
            }
        }
        if (!timThay) {
            System.out.println(">>> Không tìm thấy hóa đơn với từ khóa: " + tuKhoa);
        }
    }

    // ==================== ĐỌC FILE ====================
    @Override
    public void docFile(String tenFile) {
        File file = new File(tenFile);
        if (!file.exists()) {
            System.out.println(">>> Không tìm thấy file: " + tenFile);
            return;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8))) {
            String dong;
            danhSach.clear();
            int dem = 0;
            while ((dong = br.readLine()) != null) {
                dong = dong.trim();
                if (dong.isEmpty()) continue;
                String[] parts = dong.split("\\|");
                if (parts.length < 6 || !parts[0].equals("HD")) {
                    System.out.println(">>> Bỏ qua dòng không đúng định dạng hóa đơn: " + dong);
                    continue;
                }
                // Mỗi dòng xử lý riêng: dòng lỗi chỉ bị bỏ qua, không làm văng chương trình
                try {
                    String maHD   = parts[1];
                    String maKH   = parts[2];
                    String tenKH  = parts[3];
                    String maNV   = parts[4];
                    String ngayLap = parts[5];
                    double tongTienDoc = parts.length > 6 ? Double.parseDouble(parts[6]) : 0;
                    String sdt    = parts.length > 7 ? parts[7] : "";
                    double giamGia = parts.length > 8 ? Double.parseDouble(parts[8]) : 0;
                    String bacSi  = parts.length > 9 ? parts[9] : "";
                    String maDon  = parts.length > 10 ? parts[10] : "";
                    String chiTiet = parts.length > 11 ? parts[11] : "";

                    HoaDon hd = new HoaDon(maHD, maKH, tenKH, sdt, maNV, ngayLap, giamGia);
                    hd.setBacSiKeDon(bacSi);
                    hd.setMaDonThuoc(maDon);
                    hd.setTongTienLuu(tongTienDoc);
                    hd.docChiTietTuChuoi(chiTiet);
                    danhSach.add(hd);
                    dem++;
                } catch (NumberFormatException e) {
                    System.out.println(">>> Bỏ qua dòng lỗi dữ liệu số: " + dong);
                }
            }
            br.close();
            thoiGianDocFile = file.lastModified();
            System.out.println(">>> Tự động nạp " + dem + " hóa đơn từ file: " + tenFile);
        } catch (IOException e) {
            System.out.println(">>> Lỗi khi đọc file: " + e.getMessage());
        }
    }

    // ==================== GHI FILE ====================
    @Override
    public void ghiFile(String tenFile) {
        try {
            File file = new File(tenFile);
            if (file.getParentFile() != null) {
                file.getParentFile().mkdirs();
            }
            BufferedWriter bw = new BufferedWriter(new FileWriter(file, StandardCharsets.UTF_8));
            for (HoaDon hd : danhSach) {
                bw.write(hd.toString());
                bw.newLine();
            }
            bw.close();
            thoiGianDocFile = file.lastModified();
            System.out.println(">>> Tự động cập nhật file: " + tenFile);
        } catch (IOException e) {
            System.out.println(">>> Lỗi khi ghi file: " + e.getMessage());
        }
    }

    // ==================== MENU ====================
    public void hienMenu() {
        hienMenu(this.sc, null, null, null);
    }

    public void hienMenu(Scanner sc) {
        hienMenu(sc, null, null, null);
    }

    public void hienMenu(Scanner sc, QuanLyThuoc qlThuoc, QuanLyKhachHang qlKhachHang, QuanLyNhanVien qlNhanVien) {
        this.sc = sc;
        kiemTraVaNapLai();
        int luaChon = -1;
        do {
            System.out.println("\n╔══════════════════════════════════╗");
            System.out.println("║        QUẢN LÝ HÓA ĐƠN           ║");
            System.out.println("╠══════════════════════════════════╣");
            System.out.println("║  1. Tạo hóa đơn mới              ║");
            System.out.println("║  2. Hiển thị danh sách hóa đơn   ║");
            System.out.println("║  3. Tìm kiếm hóa đơn             ║");
            System.out.println("║  4. Đọc dữ liệu từ file          ║");
            System.out.println("║  5. Ghi dữ liệu ra file          ║");
            System.out.println("║  0. Quay lại menu trước          ║");
            System.out.println("╚══════════════════════════════════╝");
            System.out.print("Nhập lựa chọn của bạn: ");

            try {
                luaChon = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println(">>> Vui lòng nhập số!");
                continue;
            }

            switch (luaChon) {
                case 1: taoHoaDon(sc, null, qlThuoc, qlKhachHang, qlNhanVien); break;
                case 2: hienDanhSach(); break;
                case 3: timKiem(); break;
                case 4:
                    System.out.print("Nhập tên file cần đọc: ");
                    String fileDoc = sc.nextLine().trim();
                    docFile(fileDoc);
                    break;
                case 5:
                    System.out.print("Nhập tên file cần ghi: ");
                    String fileGhi = sc.nextLine().trim();
                    ghiFile(fileGhi);
                    break;
                case 0:
                    break;
                default:
                    System.out.println(">>> Lựa chọn không hợp lệ! Vui lòng chọn từ 0-5.");
            }
        } while (luaChon != 0);
    }
}
