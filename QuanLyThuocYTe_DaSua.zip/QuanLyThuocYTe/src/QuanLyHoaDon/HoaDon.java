package QuanLyHoaDon;

import java.util.*;

public class HoaDon {
    // Thuộc tính
    private String maHD;
    private String maKH;
    private String tenKH;
    private String soDienThoai;
    private String maNV;
    private String ngayLap;
    private double giamGia;
    private double tongTienLuu = -1;
    private String bacSiKeDon = "";
    private String maDonThuoc = "";

    // Danh sách thuốc trong hóa đơn
    private ArrayList<String> danhSachMaThuoc;
    private ArrayList<Double> danhSachGia;
    private ArrayList<Integer> danhSachSoLuong;

    // Đếm số lượng hóa đơn đã tạo
    public static int demHoaDon = 0;

    // Constructor đầy đủ
    public HoaDon(String maHD, String maKH, String tenKH, String soDienThoai, String maNV, String ngayLap, double giamGia) {
        this.maHD = maHD;
        this.maKH = maKH;
        this.tenKH = tenKH;
        this.soDienThoai = soDienThoai != null ? soDienThoai : "";
        this.maNV = maNV;
        this.ngayLap = ngayLap;
        this.giamGia = giamGia;
        this.tongTienLuu = -1;
        this.bacSiKeDon = "";
        this.maDonThuoc = "";
        this.danhSachMaThuoc = new ArrayList<>();
        this.danhSachGia = new ArrayList<>();
        this.danhSachSoLuong = new ArrayList<>();
        demHoaDon++;
    }

    // Constructor đơn giản (tương thích cũ)
    public HoaDon(String maHD, String maKH, String tenKH, String maNV, String ngayLap) {
        this(maHD, maKH, tenKH, "", maNV, ngayLap, 0);
    }

    public void setTongTienLuu(double tongTienLuu) {
        this.tongTienLuu = tongTienLuu;
    }

    // Tính tổng tiền thuốc trước khi giảm giá
    public double tinhTongTien() {
        if (!danhSachMaThuoc.isEmpty()) {
            double tong = 0;
            for (int i = 0; i < danhSachMaThuoc.size(); i++) {
                tong += danhSachGia.get(i) * danhSachSoLuong.get(i);
            }
            return tong;
        }
        return tongTienLuu > 0 ? (tongTienLuu + giamGia) : 0;
    }

    // Tiền khách thực thanh toán sau khi trừ giảm giá
    public double tinhThanhToan() {
        if (!danhSachMaThuoc.isEmpty()) {
            double tt = tinhTongTien() - giamGia;
            return tt < 0 ? 0 : tt;
        }
        return tongTienLuu > 0 ? tongTienLuu : 0;
    }

    // Thêm thuốc vào hóa đơn
    public void themThuoc(String maThuoc, double gia, int soLuong) {
        danhSachMaThuoc.add(maThuoc);
        danhSachGia.add(gia);
        danhSachSoLuong.add(soLuong);
    }

    // Hiển thị thông tin đầy đủ
    public void hienThongTin() {
        System.out.println("============================================================");
        System.out.println("  HÓA ĐƠN BÁN HÀNG: " + maHD);
        System.out.println("============================================================");
        System.out.printf("  Mã KH    : %-15s Tên KH   : %s%n", maKH, tenKH);
        System.out.printf("  Số ĐT    : %-15s Ngày lập : %s%n", (soDienThoai.isEmpty() ? "(Không có)" : soDienThoai), ngayLap);
        System.out.printf("  Mã NV bán: %-15s%n", maNV);
        if (!bacSiKeDon.isEmpty() || !maDonThuoc.isEmpty()) {
            System.out.printf("  Bác sĩ kê: %-15s Đơn thuốc: %s%n",
                    (bacSiKeDon.isEmpty() ? "N/A" : bacSiKeDon),
                    (maDonThuoc.isEmpty() ? "N/A" : maDonThuoc));
        }
        System.out.println("------------------------------------------------------------");
        System.out.printf("  %-4s %-12s %14s %8s %16s%n",
                "STT", "Mã thuốc", "Đơn giá", "SL", "Thành tiền");
        System.out.println("------------------------------------------------------------");
        for (int i = 0; i < danhSachMaThuoc.size(); i++) {
            double thanhTien = danhSachGia.get(i) * danhSachSoLuong.get(i);
            System.out.printf("  %-4d %-12s %,14.0f %8d %,16.0f%n",
                    (i + 1),
                    danhSachMaThuoc.get(i),
                    danhSachGia.get(i),
                    danhSachSoLuong.get(i),
                    thanhTien);
        }
        System.out.println("------------------------------------------------------------");
        System.out.printf("  Tổng tiền hàng: %,.0f VNĐ%n", tinhTongTien());
        if (giamGia > 0) {
            System.out.printf("  Giảm giá      : -%,.0f VNĐ%n", giamGia);
        }
        System.out.printf("  THANH TOÁN    : %,.0f VNĐ%n", tinhThanhToan());
        System.out.println("============================================================");
    }

    // Chuyển đổi sang format pipe để ghi file
    // Cột cuối lưu chi tiết thuốc đã bán: maThuoc:donGia:soLuong;maThuoc:donGia:soLuong...
    @Override
    public String toString() {
        return "HD|" + maHD + "|" + maKH + "|" + tenKH + "|" + maNV + "|" + ngayLap + "|" + tinhThanhToan()
                + "|" + soDienThoai + "|" + giamGia + "|" + bacSiKeDon + "|" + maDonThuoc
                + "|" + chiTietThanhChuoi();
    }

    /** Ghép danh sách thuốc trong hóa đơn thành chuỗi để lưu file */
    public String chiTietThanhChuoi() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < danhSachMaThuoc.size(); i++) {
            if (i > 0) sb.append(";");
            sb.append(danhSachMaThuoc.get(i)).append(":")
              .append(danhSachGia.get(i)).append(":")
              .append(danhSachSoLuong.get(i));
        }
        return sb.toString();
    }

    /**
     * Đọc lại danh sách thuốc từ chuỗi đã lưu trong file.
     * Tách từ bên phải để mã thuốc có chứa dấu ':' vẫn đọc đúng.
     */
    public void docChiTietTuChuoi(String chuoi) {
        if (chuoi == null || chuoi.trim().isEmpty()) return;
        for (String muc : chuoi.split(";")) {
            int viTriSoLuong = muc.lastIndexOf(':');
            int viTriGia = viTriSoLuong > 0 ? muc.lastIndexOf(':', viTriSoLuong - 1) : -1;
            if (viTriGia <= 0) continue;
            String ma = muc.substring(0, viTriGia);
            double gia = Double.parseDouble(muc.substring(viTriGia + 1, viTriSoLuong));
            int soLuong = Integer.parseInt(muc.substring(viTriSoLuong + 1));
            themThuoc(ma, gia, soLuong);
        }
    }

    // ==================== GETTER / SETTER ====================

    public String getBacSiKeDon() { return bacSiKeDon; }
    public void setBacSiKeDon(String bacSiKeDon) { this.bacSiKeDon = bacSiKeDon; }

    public String getMaDonThuoc() { return maDonThuoc; }
    public void setMaDonThuoc(String maDonThuoc) { this.maDonThuoc = maDonThuoc; }

    public String getMaHD() { return maHD; }
    public void setMaHD(String maHD) { this.maHD = maHD; }

    public String getMaKH() { return maKH; }
    public void setMaKH(String maKH) { this.maKH = maKH; }

    public String getTenKH() { return tenKH; }
    public void setTenKH(String tenKH) { this.tenKH = tenKH; }

    public String getSoDienThoai() { return soDienThoai; }
    public void setSoDienThoai(String soDienThoai) { this.soDienThoai = soDienThoai; }

    public String getMaNV() { return maNV; }
    public void setMaNV(String maNV) { this.maNV = maNV; }

    public String getNgayLap() { return ngayLap; }
    public void setNgayLap(String ngayLap) { this.ngayLap = ngayLap; }

    public double getGiamGia() { return giamGia; }
    public void setGiamGia(double giamGia) { this.giamGia = giamGia; }

    public ArrayList<String> getDanhSachMaThuoc() { return danhSachMaThuoc; }
    public void setDanhSachMaThuoc(ArrayList<String> danhSachMaThuoc) { this.danhSachMaThuoc = danhSachMaThuoc; }

    public ArrayList<Double> getDanhSachGia() { return danhSachGia; }
    public void setDanhSachGia(ArrayList<Double> danhSachGia) { this.danhSachGia = danhSachGia; }

    public ArrayList<Integer> getDanhSachSoLuong() { return danhSachSoLuong; }
    public void setDanhSachSoLuong(ArrayList<Integer> danhSachSoLuong) { this.danhSachSoLuong = danhSachSoLuong; }
}
