package QuanLyHoaDon;

public interface IHoaDonAction {
    void taoHoaDon();
    void hienDanhSach();
    void timKiem();
    void docFile(String tenFile);
    void ghiFile(String tenFile);
}
