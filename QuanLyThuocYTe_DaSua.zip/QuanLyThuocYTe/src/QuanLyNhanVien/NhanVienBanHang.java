package QuanLyNhanVien;

/**
 * Lớp NhanVienBanHang - nhân viên bán hàng được hưởng hoa hồng doanh số
 */
public class NhanVienBanHang extends NhanVien {

    // Thuộc tính riêng
    private double doanhSoThang;
    private double phanTramHoaHong;

    // Biến đếm số nhân viên bán hàng
    public static int demBanHang = 0;

    // Constructor đầy đủ
    public NhanVienBanHang(String maNV, String tenNV, String soDienThoai,
                           String ngayVaoLam, double luongCoBan, double doanhSoThang) {
        super(maNV, tenNV, soDienThoai, ngayVaoLam, luongCoBan);
        this.doanhSoThang = doanhSoThang;
        this.phanTramHoaHong = 0.02; // 2% hoa hong mac dinh
        demBanHang++;
    }

    // ==================== Getter / Setter ====================

    public double getDoanhSoThang() {
        return doanhSoThang;
    }

    public void setDoanhSoThang(double doanhSoThang) {
        this.doanhSoThang = doanhSoThang;
    }

    public double getPhanTramHoaHong() {
        return phanTramHoaHong;
    }

    public void setPhanTramHoaHong(double phanTramHoaHong) {
        this.phanTramHoaHong = phanTramHoaHong;
    }

    // ==================== Override ====================

    @Override
    public double tinhLuong() {
        // Luong = luong co ban + doanh so * % hoa hong
        return getLuongCoBan() + doanhSoThang * phanTramHoaHong;
    }

    @Override
    public void hienThongTin() {
        System.out.println("--------------------------------------------------");
        System.out.println("Mã NV          : " + getMaNV());
        System.out.println("Tên NV         : " + getTenNV());
        System.out.println("Số Điện Thoại  : " + getSoDienThoai());
        System.out.println("Ngày Vào Làm   : " + getNgayVaoLam());
        System.out.println("Loại NV        : " + getLoaiNV());
        System.out.printf ("Lương Cơ Bản   : %,.0f VNĐ%n", getLuongCoBan());
        System.out.printf ("Doanh Số Tháng : %,.0f VNĐ%n", doanhSoThang);
        System.out.printf ("Hoa Hồng (%.0f%%): %,.0f VNĐ%n", phanTramHoaHong * 100,
                           doanhSoThang * phanTramHoaHong);
        System.out.printf ("Lương tạm tính : %,.0f VNĐ%n", tinhLuong());
        System.out.println("--------------------------------------------------");
    }

    /**
     * Hiển thị cho nhân viên tự xem:
     * Chỉ thấy Doanh số tháng và Hoa hồng tạm tính, KHÔNG hiển thị Lương cơ bản và Lương tạm tính.
     */
    public void hienThongTinNhanVienXem() {
        System.out.println("--------------------------------------------------");
        System.out.println("Mã NV             : " + getMaNV());
        System.out.println("Tên NV            : " + getTenNV());
        System.out.println("Số Điện Thoại     : " + getSoDienThoai());
        System.out.println("Ngày Vào Làm      : " + getNgayVaoLam());
        System.out.println("Loại NV           : " + getLoaiNV());
        System.out.printf ("Doanh Số Tháng    : %,.0f VNĐ%n", doanhSoThang);
        System.out.printf ("Tỷ Lệ Hoa Hồng    : %.0f%%%n", phanTramHoaHong * 100);
        System.out.printf ("Hoa Hồng Tạm Tính : %,.0f VNĐ%n", doanhSoThang * phanTramHoaHong);
        System.out.println("--------------------------------------------------");
    }

    @Override
    public String getLoaiNV() {
        return "Ban Hang";
    }
}
