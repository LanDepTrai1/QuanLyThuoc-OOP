package QuanLyNhanVien;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.time.format.DateTimeParseException;

/**
 * Lớp trừu tượng đại diện cho nhân viên
 */
public abstract class NhanVien {
    // Thuộc tính riêng tư
    private String maNV;
    private String tenNV;
    private String soDienThoai;
    private String ngayVaoLam;
    private double luongCoBan;

    private static final DateTimeFormatter DATE_FORMATTER =
            DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT);

    // Biến đếm tổng số nhân viên
    public static int demNV = 0;

    // Constructor đầy đủ
    public NhanVien(String maNV, String tenNV, String soDienThoai,
                    String ngayVaoLam, double luongCoBan) {
        this.maNV = maNV;
        this.tenNV = tenNV;
        this.soDienThoai = soDienThoai;
        this.ngayVaoLam = ngayVaoLam;
        this.luongCoBan = luongCoBan;
        demNV++;
    }

    // Hiển thị tổng số nhân viên
    public static void inTongSo() {
        System.out.println("Tong so nhan vien: " + demNV);
    }

    /**
     * Ràng buộc kiểm tra định dạng ngày:
     * - Định dạng chuẩn dd/MM/yyyy (nghiêm ngặt theo lịch)
     * - Năm: 2010 <= năm <= 2050
     */
    public static boolean kiemTraNgayHopLe(String ngayStr) {
        if (ngayStr == null) return false;
        String s = ngayStr.trim();
        if (!s.matches("^\\d{2}/\\d{2}/\\d{4}$")) {
            return false;
        }
        try {
            LocalDate date = LocalDate.parse(s, DATE_FORMATTER);
            int nam = date.getYear();
            return nam >= 2010 && nam <= 2050;
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    /**
     * Ràng buộc số điện thoại: 10 chữ số, bắt đầu bằng 0
     */
    public static boolean soDienThoaiHopLe(String sdt) {
        return sdt != null && sdt.trim().matches("0[0-9]{9}");
    }

    // ==================== Getter / Setter ====================

    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public String getTenNV() {
        return tenNV;
    }

    public void setTenNV(String tenNV) {
        this.tenNV = tenNV;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(String soDienThoai) {
        this.soDienThoai = soDienThoai;
    }

    public String getNgayVaoLam() {
        return ngayVaoLam;
    }

    public void setNgayVaoLam(String ngayVaoLam) {
        this.ngayVaoLam = ngayVaoLam;
    }

    public double getLuongCoBan() {
        return luongCoBan;
    }

    public void setLuongCoBan(double luongCoBan) {
        this.luongCoBan = luongCoBan;
    }

    // ==================== Phương thức trừu tượng ====================

    /** Tính lương thực tế của nhân viên */
    public abstract double tinhLuong();

    /** Hiển thị thông tin chi tiết nhân viên */
    public abstract void hienThongTin();

    /** Trả về loại nhân viên */
    public abstract String getLoaiNV();
}
