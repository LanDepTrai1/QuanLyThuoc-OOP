package QuanLyNhanVien;

/**
 * Interface định nghĩa các hành động quản lý nhân viên
 */
public interface INhanVienAction {
    void them();
    void sua();
    void xoa();
    void timKiem();
    void hienDanhSach();
    void docFile(String tenFile);
    void ghiFile(String tenFile);
}
