package QuanLyNhanVien;

/**
 * Lớp NhanVienKho - nhân viên kho được hưởng phụ cấp theo ca làm
 */
public class NhanVienKho extends NhanVien {

    // Thuộc tính riêng
    private double phuCapKho;
    private int soCaLam;

    // Biến đếm số nhân viên kho
    public static int demKho = 0;

    // Constructor đầy đủ
    public NhanVienKho(String maNV, String tenNV, String soDienThoai,
                       String ngayVaoLam, double luongCoBan,
                       double phuCapKho, int soCaLam) {
        super(maNV, tenNV, soDienThoai, ngayVaoLam, luongCoBan);
        this.phuCapKho = phuCapKho;
        this.soCaLam = soCaLam;
        demKho++;
    }

    // ==================== Getter / Setter ====================

    public double getPhuCapKho() {
        return phuCapKho;
    }

    public void setPhuCapKho(double phuCapKho) {
        this.phuCapKho = phuCapKho;
    }

    public int getSoCaLam() {
        return soCaLam;
    }

    public void setSoCaLam(int soCaLam) {
        this.soCaLam = soCaLam;
    }

    // ==================== Override ====================

    @Override
    public double tinhLuong() {
        // Luong = luong co ban + phu cap kho * so ca lam
        return getLuongCoBan() + phuCapKho * soCaLam;
    }

    @Override
    public void hienThongTin() {
        hienThongTin(true);
    }

    /**
     * Hiển thị thông tin nhân viên kho.
     * @param hienSoCaLam false khi hiển thị ở chức năng Tìm kiếm nhân viên (không hiện Số ca làm)
     */
    public void hienThongTin(boolean hienSoCaLam) {
        System.out.println("--------------------------------------------------");
        System.out.println("Mã NV          : " + getMaNV());
        System.out.println("Tên NV         : " + getTenNV());
        System.out.println("Số Điện Thoại  : " + getSoDienThoai());
        System.out.println("Ngày Vào Làm   : " + getNgayVaoLam());
        System.out.println("Loại NV        : " + getLoaiNV());
        System.out.printf ("Lương Cơ Bản   : %,.0f VNĐ%n", getLuongCoBan());
        System.out.printf ("Phụ Cấp Kho/Ca : %,.0f VNĐ%n", phuCapKho);
        if (hienSoCaLam) {
            System.out.println("Số Ca Làm      : " + soCaLam + " ca");
        }
        System.out.printf ("Lương tạm tính : %,.0f VNĐ%n", tinhLuong());
        System.out.println("--------------------------------------------------");
    }

    @Override
    public String getLoaiNV() {
        return "Nhan Vien Kho";
    }
}
