package QuanLyNhanVien;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.io.*;
import QuanLyHoaDon.QuanLyHoaDon;

/**
 * Lớp QuanLyNhanVien - quản lý danh sách nhân viên
 * Implements INhanVienAction để thực hiện các chức năng CRUD + file I/O
 */
public class QuanLyNhanVien implements INhanVienAction {

    // Tên file mặc định
    private static final String FILE_MAC_DINH = "nhanvien.txt";

    // Danh sách nhân viên
    private ArrayList<NhanVien> danhSach;
    // Scanner nhập liệu
    private Scanner sc;
    // Thời điểm sửa đổi file lần cuối được nạp
    private long thoiGianDocFile = 0;

    // Constructor
    public QuanLyNhanVien() {
        danhSach = new ArrayList<>();
        sc = new Scanner(System.in);
        File file = new File(FILE_MAC_DINH);
        if (file.exists()) {
            docFile(FILE_MAC_DINH);
        }
    }

    /**
     * Tự động kiểm tra và nạp lại file nếu file nhanvien.txt bị chỉnh sửa từ bên ngoài
     */
    public void kiemTraVaNapLai() {
        File file = new File(FILE_MAC_DINH);
        if (file.exists() && file.lastModified() > thoiGianDocFile) {
            System.out.println(">>> Phát hiện file " + FILE_MAC_DINH + " vừa có thay đổi từ bên ngoài, đang tự động đồng bộ lại...");
            docFile(FILE_MAC_DINH);
        }
    }

    public void setScanner(Scanner sc) {
        if (sc != null) this.sc = sc;
    }

    public ArrayList<NhanVien> getDanhSach() {
        kiemTraVaNapLai();
        return danhSach;
    }

    public NhanVien timTheoMa(String maNV) {
        kiemTraVaNapLai();
        if (maNV == null) return null;
        for (NhanVien nv : danhSach) {
            if (nv.getMaNV().equalsIgnoreCase(maNV.trim())) {
                return nv;
            }
        }
        return null;
    }

    // ==================== THÊM NHÂN VIÊN ====================
    @Override
    public void them() {
        System.out.println("\n===== THÊM NHÂN VIÊN MỚI =====");
        int loai = 0;
        do {
            System.out.println("Chọn loại nhân viên:");
            System.out.println("  1. Nhân viên bán hàng");
            System.out.println("  2. Nhân viên kho");
            System.out.print("Nhập lựa chọn của bạn: ");
            try {
                loai = Integer.parseInt(sc.nextLine().trim());
                if (loai == 1 || loai == 2) break;
                System.out.println(">>> Lựa chọn không hợp lệ! Vui lòng chỉ chọn 1 hoặc 2.");
            } catch (NumberFormatException e) {
                System.out.println(">>> Vui lòng nhập số 1 hoặc 2!");
            }
        } while (true);

        String maNV = "";
        do {
            System.out.print("Mã nhân viên   : ");
            maNV = sc.nextLine().trim();
            if (maNV.isEmpty()) {
                System.out.println(">>> Lỗi: Mã nhân viên không được để trống!");
                continue;
            }
            if (maNV.contains("|")) {
                System.out.println(">>> Lỗi: Mã nhân viên không được chứa ký tự '|'!");
                continue;
            }
            if (timTheoMa(maNV) != null) {
                System.out.println(">>> Mã nhân viên đã tồn tại! Không thể thêm.");
                return;
            }
            break;
        } while (true);

        String tenNV = "";
        do {
            System.out.print("Tên nhân viên  : ");
            tenNV = sc.nextLine().trim().replace("|", "-");
            if (tenNV.isEmpty()) {
                System.out.println(">>> Lỗi: Tên nhân viên không được để trống!");
                continue;
            }
            break;
        } while (true);

        String sdt = "";
        do {
            System.out.print("Số điện thoại (10 chữ số): ");
            sdt = sc.nextLine().trim();
            if (!NhanVien.soDienThoaiHopLe(sdt)) {
                System.out.println(">>> Lỗi: Số điện thoại không hợp lệ! Vui lòng nhập đúng 10 chữ số (bắt đầu bằng 0).");
                continue;
            }
            break;
        } while (true);

        // Ràng buộc định dạng ngày, tháng, năm
        String ngayVaoLam = "";
        do {
            System.out.print("Ngày vào làm (dd/MM/yyyy): ");
            ngayVaoLam = sc.nextLine().trim();
            if (!NhanVien.kiemTraNgayHopLe(ngayVaoLam)) {
                System.out.println(">>> Lỗi định dạng ngày, tháng, năm!");
                System.out.println(">>> Yêu cầu: Định dạng dd/MM/yyyy (ngày hợp lệ theo lịch, năm từ 2010 đến 2050). Vui lòng nhập lại.");
                continue;
            }
            break;
        } while (true);

        double luongCoBan = 0;
        do {
            System.out.print("Lương cơ bản (> 0)  : ");
            try {
                luongCoBan = Double.parseDouble(sc.nextLine().trim());
                if (luongCoBan <= 0) {
                    System.out.println(">>> Lương cơ bản phải lớn hơn 0!");
                    continue;
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println(">>> Lương cơ bản không hợp lệ! Vui lòng nhập số.");
            }
        } while (true);

        if (loai == 1) {
            // Doanh số khởi tạo = 0, được đồng bộ tự động từ hóa đơn bán lẻ
            double doanhSo = 0;
            NhanVienBanHang nvBH = new NhanVienBanHang(maNV, tenNV, sdt, ngayVaoLam, luongCoBan, doanhSo);
            danhSach.add(nvBH);
            System.out.println(">>> Đã thêm nhân viên bán hàng thành công! (Doanh số tính từ hóa đơn đã lập)");
            ghiFile(FILE_MAC_DINH);
        } else if (loai == 2) {
            double phuCap = 0;
            do {
                System.out.print("Phụ cấp kho/ca (>= 0): ");
                try {
                    phuCap = Double.parseDouble(sc.nextLine().trim());
                    if (phuCap < 0) {
                        System.out.println(">>> Phụ cấp không được âm!");
                        continue;
                    }
                    break;
                } catch (NumberFormatException e) {
                    System.out.println(">>> Phụ cấp không hợp lệ! Vui lòng nhập số.");
                }
            } while (true);

            int soCa = 0;
            do {
                System.out.print("Số ca làm (>= 0)     : ");
                try {
                    soCa = Integer.parseInt(sc.nextLine().trim());
                    if (soCa < 0) {
                        System.out.println(">>> Số ca làm không được âm!");
                        continue;
                    }
                    break;
                } catch (NumberFormatException e) {
                    System.out.println(">>> Số ca làm không hợp lệ! Vui lòng nhập số nguyên.");
                }
            } while (true);

            NhanVienKho nvKho = new NhanVienKho(maNV, tenNV, sdt, ngayVaoLam, luongCoBan, phuCap, soCa);
            danhSach.add(nvKho);
            System.out.println(">>> Đã thêm nhân viên kho thành công!");
            ghiFile(FILE_MAC_DINH);
        }
    }

    // ==================== SỬA NHÂN VIÊN ====================
    @Override
    public void sua() {
        System.out.println("\n===== SỬA THÔNG TIN NHÂN VIÊN =====");
        System.out.print("Nhập mã nhân viên cần sửa: ");
        String maNV = sc.nextLine().trim();

        NhanVien timThay = timTheoMa(maNV);
        if (timThay == null) {
            System.out.println(">>> Không tìm thấy nhân viên có mã: " + maNV);
            return;
        }

        timThay.hienThongTin();

        System.out.print("Tên mới (Enter để giữ nguyên) : ");
        String tenMoi = sc.nextLine().trim().replace("|", "-");
        if (!tenMoi.isEmpty()) timThay.setTenNV(tenMoi);

        System.out.print("SĐT mới (Enter để giữ nguyên) : ");
        String sdtMoi = sc.nextLine().trim();
        if (!sdtMoi.isEmpty()) {
            if (NhanVien.soDienThoaiHopLe(sdtMoi)) {
                timThay.setSoDienThoai(sdtMoi);
            } else {
                System.out.println(">>> SĐT không hợp lệ (cần 10 chữ số), giữ nguyên SĐT cũ.");
            }
        }

        System.out.print("Ngày vào làm mới [" + timThay.getNgayVaoLam() + "] (Enter để giữ nguyên): ");
        String nvlMoi = sc.nextLine().trim();
        if (!nvlMoi.isEmpty()) {
            if (NhanVien.kiemTraNgayHopLe(nvlMoi)) {
                timThay.setNgayVaoLam(nvlMoi);
            } else {
                System.out.println(">>> Lỗi: Ngày vào làm không hợp lệ, giữ nguyên ngày cũ.");
            }
        }

        System.out.print("Lương cơ bản mới (Enter để giữ nguyên): ");
        String luongMoi = sc.nextLine().trim();
        if (!luongMoi.isEmpty()) {
            try {
                double lcb = Double.parseDouble(luongMoi);
                if (lcb > 0) {
                    timThay.setLuongCoBan(lcb);
                } else {
                    System.out.println(">>> Lương phải lớn hơn 0, giữ nguyên lương cũ.");
                }
            } catch (NumberFormatException e) {
                System.out.println(">>> Lương không hợp lệ, giữ nguyên.");
            }
        }

        // Sửa thêm field riêng theo loại
        if (timThay instanceof NhanVienBanHang) {
            System.out.println(">>> Lưu ý: Doanh số tháng được tính tự động từ Hóa đơn bán hàng, không thể sửa thủ công.");
        } else if (timThay instanceof NhanVienKho) {
            NhanVienKho nvKho = (NhanVienKho) timThay;
            System.out.print("Phụ cấp kho mới (Enter để giữ nguyên): ");
            String pcMoi = sc.nextLine().trim();
            if (!pcMoi.isEmpty()) {
                try {
                    double pc = Double.parseDouble(pcMoi);
                    if (pc >= 0) {
                        nvKho.setPhuCapKho(pc);
                    } else {
                        System.out.println(">>> Phụ cấp không được âm, giữ nguyên.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println(">>> Phụ cấp không hợp lệ, giữ nguyên.");
                }
            }
            System.out.print("Số ca làm mới (Enter để giữ nguyên): ");
            String soCaMoi = sc.nextLine().trim();
            if (!soCaMoi.isEmpty()) {
                try {
                    int scMoi = Integer.parseInt(soCaMoi);
                    if (scMoi >= 0) {
                        nvKho.setSoCaLam(scMoi);
                    } else {
                        System.out.println(">>> Số ca không được âm, giữ nguyên.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println(">>> Số ca không hợp lệ, giữ nguyên.");
                }
            }
        }

        System.out.println(">>> Cập nhật thông tin nhân viên thành công!");
        ghiFile(FILE_MAC_DINH);
    }

    // ==================== XÓA NHÂN VIÊN ====================
    @Override
    public void xoa() {
        System.out.println("\n===== XÓA NHÂN VIÊN =====");
        System.out.print("Nhập mã nhân viên cần xóa: ");
        String maNV = sc.nextLine().trim();

        NhanVien timThay = timTheoMa(maNV);
        if (timThay == null) {
            System.out.println(">>> Không tìm thấy nhân viên có mã: " + maNV);
            return;
        }

        timThay.hienThongTin();
        System.out.print("Bạn có chắc chắn muốn xóa? (c/k): ");
        String xacNhan = sc.nextLine().trim();
        if (xacNhan.equalsIgnoreCase("c") || xacNhan.equalsIgnoreCase("y")) {
            danhSach.remove(timThay);
            NhanVien.demNV--;
            // Giảm cả biến đếm của lớp con tương ứng
            if (timThay instanceof NhanVienBanHang) {
                NhanVienBanHang.demBanHang--;
            } else if (timThay instanceof NhanVienKho) {
                NhanVienKho.demKho--;
            }
            System.out.println(">>> Đã xóa nhân viên thành công!");
            ghiFile(FILE_MAC_DINH);
        } else {
            System.out.println(">>> Đã hủy xóa.");
        }
    }

    // ==================== TÌM KIẾM ====================
    @Override
    public void timKiem() {
        kiemTraVaNapLai();
        System.out.println("\n===== TÌM KIẾM NHÂN VIÊN =====");
        System.out.println("  1. Tìm theo Mã NV");
        System.out.println("  2. Tìm theo Tên NV");
        System.out.print("Nhập lựa chọn của bạn: ");
        int luaChon = 0;
        try {
            luaChon = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println(">>> Lựa chọn không hợp lệ!");
            return;
        }

        System.out.print("Nhập từ khóa tìm kiếm: ");
        String tuKhoa = sc.nextLine().trim().toLowerCase();

        boolean timThay = false;
        for (NhanVien nv : danhSach) {
            boolean khop = false;
            if (luaChon == 1) {
                khop = nv.getMaNV().toLowerCase().contains(tuKhoa);
            } else if (luaChon == 2) {
                khop = nv.getTenNV().toLowerCase().contains(tuKhoa);
            }
            if (khop) {
                if (nv instanceof NhanVienKho) {
                    // Tìm kiếm không hiển thị mục "Số ca làm"
                    ((NhanVienKho) nv).hienThongTin(false);
                } else {
                    nv.hienThongTin();
                }
                timThay = true;
            }
        }
        if (!timThay) {
            System.out.println(">>> Không tìm thấy nhân viên nào phù hợp!");
        }
    }

    /**
     * Đồng bộ doanh số thực tế từ danh sách hóa đơn cho toàn bộ nhân viên bán hàng
     */
    public void dongBoDoanhSoTuHoaDon(QuanLyHoaDon qlHoaDon) {
        if (qlHoaDon == null) return;
        kiemTraVaNapLai();
        boolean coThayDoi = false;
        for (NhanVien nv : danhSach) {
            if (nv instanceof NhanVienBanHang) {
                NhanVienBanHang nvBH = (NhanVienBanHang) nv;
                double dsThucTe = qlHoaDon.tinhTongDoanhSoTheoNV(nvBH.getMaNV());
                if (Math.abs(nvBH.getDoanhSoThang() - dsThucTe) > 0.001) {
                    nvBH.setDoanhSoThang(dsThucTe);
                    coThayDoi = true;
                }
            }
        }
        if (coThayDoi) {
            ghiFile(FILE_MAC_DINH);
        }
    }

    // ==================== HIỂN THỊ DANH SÁCH ====================
    @Override
    public void hienDanhSach() {
        kiemTraVaNapLai();
        System.out.println("\n===== DANH SÁCH NHÂN VIÊN =====");
        if (danhSach.isEmpty()) {
            System.out.println("  (Danh sách trống)");
            return;
        }
        System.out.println("+---------+----------------------+---------------+--------------+-----------------+-------------------+");
        System.out.printf("| %-7s | %-20s | %-13s | %-12s | %-15s | %17s |%n",
                "Mã NV", "Tên NV", "Số ĐT", "Ngày vào làm", "Loại NV", "Lương tạm tính");
        System.out.println("+---------+----------------------+---------------+--------------+-----------------+-------------------+");
        for (NhanVien nv : danhSach) {
            System.out.printf("| %-7s | %-20s | %-13s | %-12s | %-15s | %,17.0f |%n",
                    nv.getMaNV(),
                    nv.getTenNV(),
                    nv.getSoDienThoai(),
                    nv.getNgayVaoLam(),
                    nv.getLoaiNV(),
                    nv.tinhLuong());
        }
        System.out.println("+---------+----------------------+---------------+--------------+-----------------+-------------------+");
        System.out.println("Tổng số nhân viên: " + danhSach.size());
    }

    // ==================== ĐỌC FILE ====================
    @Override
    public void docFile(String tenFile) {
        try {
            File file = new File(tenFile);
            if (!file.exists()) {
                System.out.println(">>> Không tìm thấy file: " + tenFile);
                return;
            }

            BufferedReader br = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8));
            String dong;
            int demDoc = 0;
            danhSach.clear();
            NhanVien.demNV = 0;
            NhanVienBanHang.demBanHang = 0;
            NhanVienKho.demKho = 0;

            while ((dong = br.readLine()) != null) {
                dong = dong.trim();
                if (dong.isEmpty()) continue;

                // Lọc bỏ phần tử rỗng nếu người dùng vô tình gõ dư dấu | (ví dụ ||)
                ArrayList<String> dsPhan = new ArrayList<>();
                for (String p : dong.split("\\|")) {
                    String pt = p.trim();
                    if (!pt.isEmpty()) {
                        dsPhan.add(pt);
                    }
                }
                if (dsPhan.size() < 7) {
                    System.out.println(">>> Bỏ qua dòng thiếu dữ liệu: " + dong);
                    continue;
                }

                // Mỗi dòng xử lý riêng: dòng lỗi chỉ bị bỏ qua, không làm mất các nhân viên khác
                try {
                    String maNV       = dsPhan.get(0);
                    String tenNV      = dsPhan.get(1);
                    String sdt        = dsPhan.get(2);
                    String ngayVaoLam = dsPhan.get(3);
                    double luongCoBan = Double.parseDouble(dsPhan.get(4));
                    String loai       = dsPhan.get(5);

                    // Kiểm tra dữ liệu giống như khi nhập từ bàn phím
                    if (!NhanVien.soDienThoaiHopLe(sdt)) {
                        throw new IllegalArgumentException("số điện thoại không hợp lệ");
                    }
                    if (!NhanVien.kiemTraNgayHopLe(ngayVaoLam)) {
                        throw new IllegalArgumentException("ngày vào làm không hợp lệ");
                    }
                    if (luongCoBan <= 0) {
                        throw new IllegalArgumentException("lương cơ bản phải lớn hơn 0");
                    }
                    for (NhanVien daCo : danhSach) {
                        if (daCo.getMaNV().equalsIgnoreCase(maNV)) {
                            throw new IllegalArgumentException("trùng mã nhân viên " + maNV);
                        }
                    }

                    if (loai.equalsIgnoreCase("Ban Hang") || loai.equalsIgnoreCase("Bán Hàng") || loai.toLowerCase().contains("ban hang")) {
                        double doanhSo        = Double.parseDouble(dsPhan.get(6));
                        double phanTramHoaHong = dsPhan.size() > 7 ? Double.parseDouble(dsPhan.get(7)) : 0.02;
                        if (doanhSo < 0 || phanTramHoaHong < 0 || phanTramHoaHong > 1) {
                            throw new IllegalArgumentException("doanh số hoặc tỷ lệ hoa hồng không hợp lệ");
                        }
                        NhanVienBanHang nvBH  = new NhanVienBanHang(maNV, tenNV, sdt, ngayVaoLam, luongCoBan, doanhSo);
                        nvBH.setPhanTramHoaHong(phanTramHoaHong);
                        danhSach.add(nvBH);
                        demDoc++;
                    } else if (loai.equalsIgnoreCase("Nhan Vien Kho") || loai.equalsIgnoreCase("Nhân Viên Kho") || loai.toLowerCase().contains("kho")) {
                        double phuCapKho = Double.parseDouble(dsPhan.get(6));
                        int soCaLam     = dsPhan.size() > 7 ? Integer.parseInt(dsPhan.get(7)) : 0;
                        if (phuCapKho < 0 || soCaLam < 0) {
                            throw new IllegalArgumentException("phụ cấp hoặc số ca làm bị âm");
                        }
                        NhanVienKho nvKho = new NhanVienKho(maNV, tenNV, sdt, ngayVaoLam, luongCoBan, phuCapKho, soCaLam);
                        danhSach.add(nvKho);
                        demDoc++;
                    } else {
                        System.out.println(">>> Bỏ qua dòng có loại nhân viên không xác định: " + dong);
                    }
                } catch (NumberFormatException e) {
                    System.out.println(">>> Bỏ qua dòng lỗi dữ liệu số: " + dong);
                } catch (IllegalArgumentException e) {
                    System.out.println(">>> Bỏ qua dòng lỗi dữ liệu (" + e.getMessage() + "): " + dong);
                }
            }

            br.close();
            thoiGianDocFile = file.lastModified();
            System.out.println(">>> Tự động nạp " + demDoc + " nhân viên từ file: " + tenFile);

        } catch (IOException e) {
            System.out.println(">>> Lỗi đọc file: " + e.getMessage());
        }
    }

    // ==================== GHI FILE ====================
    @Override
    public void ghiFile(String tenFile) {
        try {
            File file = new File(tenFile);
            if (file.getParentFile() != null) {
                file.getParentFile().mkdirs();
            }

            BufferedWriter bw = new BufferedWriter(new FileWriter(file, StandardCharsets.UTF_8));

            for (NhanVien nv : danhSach) {
                StringBuilder sb = new StringBuilder();
                sb.append(nv.getMaNV()).append("|");
                sb.append(nv.getTenNV()).append("|");
                sb.append(nv.getSoDienThoai()).append("|");
                sb.append(nv.getNgayVaoLam()).append("|");
                sb.append(nv.getLuongCoBan()).append("|");
                sb.append(nv.getLoaiNV()).append("|");

                if (nv instanceof NhanVienBanHang) {
                    NhanVienBanHang nvBH = (NhanVienBanHang) nv;
                    sb.append(nvBH.getDoanhSoThang()).append("|");
                    sb.append(nvBH.getPhanTramHoaHong());
                } else if (nv instanceof NhanVienKho) {
                    NhanVienKho nvKho = (NhanVienKho) nv;
                    sb.append(nvKho.getPhuCapKho()).append("|");
                    sb.append(nvKho.getSoCaLam());
                }

                bw.write(sb.toString());
                bw.newLine();
            }

            bw.close();
            thoiGianDocFile = file.lastModified();
            System.out.println(">>> Tự động cập nhật file: " + tenFile);

        } catch (IOException e) {
            System.out.println(">>> Lỗi ghi file: " + e.getMessage());
        }
    }

    // ==================== MENU ====================
    public void hienMenu() {
        hienMenu(this.sc);
    }

    public void hienMenu(Scanner sc) {
        this.sc = sc;
        kiemTraVaNapLai();
        int luaChon = -1;
        do {
            System.out.println("\n╔══════════════════════════════════╗");
            System.out.println("║       QUẢN LÝ NHÂN VIÊN          ║");
            System.out.println("╠══════════════════════════════════╣");
            System.out.println("║  1. Thêm nhân viên               ║");
            System.out.println("║  2. Sửa thông tin nhân viên      ║");
            System.out.println("║  3. Xóa nhân viên                ║");
            System.out.println("║  4. Tìm kiếm nhân viên           ║");
            System.out.println("║  5. Hiển thị danh sách           ║");
            System.out.println("║  6. Đọc dữ liệu từ file          ║");
            System.out.println("║  7. Ghi dữ liệu ra file          ║");
            System.out.println("║  0. Quay lại menu trước          ║");
            System.out.println("╚══════════════════════════════════╝");
            System.out.print("Nhập lựa chọn của bạn: ");

            try {
                luaChon = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println(">>> Vui lòng nhập số!");
                continue;
            }

            switch (luaChon) {
                case 1: them(); break;
                case 2: sua(); break;
                case 3: xoa(); break;
                case 4: timKiem(); break;
                case 5: hienDanhSach(); break;
                case 6:
                    System.out.print("Nhập tên file cần đọc: ");
                    String fileDoc = sc.nextLine().trim();
                    docFile(fileDoc);
                    break;
                case 7:
                    System.out.print("Nhập tên file cần ghi: ");
                    String fileGhi = sc.nextLine().trim();
                    ghiFile(fileGhi);
                    break;
                case 0:
                    break;
                default:
                    System.out.println(">>> Lựa chọn không hợp lệ! Vui lòng chọn từ 0-7.");
            }
        } while (luaChon != 0);
    }
}
