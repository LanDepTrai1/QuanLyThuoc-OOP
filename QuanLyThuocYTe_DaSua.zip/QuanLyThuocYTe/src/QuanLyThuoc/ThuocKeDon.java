package QuanLyThuoc;

/**
 * Lớp ThuocKeDon - thuốc bán theo đơn của bác sĩ
 * Kế thừa từ lớp Thuoc
 */
public class ThuocKeDon extends Thuoc {
    // Đếm số lượng thuốc kê đơn đã tạo
    public static int demKeDon = 0;

    /**
     * Constructor đầy đủ tham số
     */
    public ThuocKeDon(String maThuoc, String tenThuoc, double giaBan, int soLuong, String hanSuDung) {
        super(maThuoc, tenThuoc, giaBan, soLuong, hanSuDung);
        demKeDon++;
    }

    /**
     * Hiển thị số lượng thuốc kê đơn đã tạo
     */
    public static void hienSoLuongKeDon() {
        System.out.println("Tổng số Thuốc kê đơn đã tạo: " + demKeDon);
    }

    /**
     * Override - hiển thị đầy đủ thông tin thuốc kê đơn
     */
    @Override
    public void hienThongTin() {
        System.out.println("+-------------------------------------------------+");
        System.out.println("| Loại thuốc   : " + getLoaiThuoc());
        System.out.println("| Mã thuốc     : " + getMaThuoc());
        System.out.println("| Tên thuốc    : " + getTenThuoc());
        System.out.println("| Giá bán      : " + String.format("%,.0f", getGiaBan()) + " VNĐ");
        System.out.println("| Số lượng     : " + getSoLuong());
        System.out.println("| Hạn sử dụng  : " + getHanSuDung());
        System.out.println("+-------------------------------------------------+");
    }

    /**
     * Override - trả về loại thuốc
     */
    @Override
    public String getLoaiThuoc() {
        return "Thuốc Kê Đơn";
    }
}
