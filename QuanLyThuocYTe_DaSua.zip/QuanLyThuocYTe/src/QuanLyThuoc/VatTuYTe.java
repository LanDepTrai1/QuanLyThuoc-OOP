package QuanLyThuoc;

/**
 * Lớp VatTuYTe - vật tư y tế
 * Kế thừa từ lớp Thuoc
 */
public class VatTuYTe extends Thuoc {
    // Đếm số lượng vật tư y tế đã tạo
    public static int demVatTu = 0;

    // Thuộc tính riêng của vật tư y tế
    private String loaiVatTu;
    private String nhaSanXuat;

    /**
     * Constructor đầy đủ tham số
     */
    public VatTuYTe(String maThuoc, String tenThuoc, double giaBan, int soLuong,
                    String hanSuDung, String loaiVatTu, String nhaSanXuat) {
        super(maThuoc, tenThuoc, giaBan, soLuong, hanSuDung);
        this.loaiVatTu = loaiVatTu;
        this.nhaSanXuat = nhaSanXuat;
        demVatTu++;
    }

    // ===== Getter và Setter =====

    public String getLoaiVatTu() {
        return loaiVatTu;
    }

    public void setLoaiVatTu(String loaiVatTu) {
        this.loaiVatTu = loaiVatTu;
    }

    public String getNhaSanXuat() {
        return nhaSanXuat;
    }

    public void setNhaSanXuat(String nhaSanXuat) {
        this.nhaSanXuat = nhaSanXuat;
    }

    /**
     * Hiển thị số lượng vật tư y tế đã tạo
     */
    public static void hienSoLuongVatTu() {
        System.out.println("Tổng số Vật tư y tế đã tạo: " + demVatTu);
    }

    /**
     * Override - hiển thị đầy đủ thông tin vật tư y tế
     */
    @Override
    public void hienThongTin() {
        System.out.println("+-------------------------------------------------+");
        System.out.println("| Loại         : " + getLoaiThuoc());
        System.out.println("| Mã vật tư    : " + getMaThuoc());
        System.out.println("| Tên vật tư   : " + getTenThuoc());
        System.out.println("| Giá bán      : " + String.format("%,.0f", getGiaBan()) + " VNĐ");
        System.out.println("| Số lượng     : " + getSoLuong());
        System.out.println("| Hạn sử dụng  : " + getHanSuDung());
        System.out.println("| Loại vật tư  : " + loaiVatTu);
        System.out.println("| Nhà sản xuất : " + nhaSanXuat);
        System.out.println("+-------------------------------------------------+");
    }

    /**
     * Override - trả về loại
     */
    @Override
    public String getLoaiThuoc() {
        return "Vật Tư Y Tế";
    }
}
