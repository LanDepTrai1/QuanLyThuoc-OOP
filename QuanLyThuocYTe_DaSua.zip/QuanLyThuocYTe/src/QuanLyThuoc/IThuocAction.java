package QuanLyThuoc;

/**
 * Interface định nghĩa các hành động quản lý thuốc
 */
public interface IThuocAction {
    void them();
    void sua();
    void xoa();
    void timKiem();
    void hienDanhSach();
    void docFile(String tenFile);
    void ghiFile(String tenFile);
}
