package QuanLyThuoc;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.time.format.DateTimeParseException;

/**
 * Lớp trừu tượng Thuoc - lớp cha cho tất cả các loại thuốc và vật tư y tế
 */
public abstract class Thuoc {
    // Đếm tổng số đối tượng Thuoc đã tạo
    public static int demThuoc = 0;

    private static final DateTimeFormatter DATE_FORMATTER =
            DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT);

    // Các thuộc tính riêng tư
    private String maThuoc;
    private String tenThuoc;
    private double giaBan;
    private int soLuong;
    private String hanSuDung;

    /**
     * Constructor đầy đủ tham số
     * Mỗi lần tạo đối tượng sẽ tăng demThuoc lên 1
     */
    public Thuoc(String maThuoc, String tenThuoc, double giaBan, int soLuong, String hanSuDung) {
        this.maThuoc = maThuoc;
        this.tenThuoc = tenThuoc;
        this.giaBan = giaBan;
        this.soLuong = soLuong;
        this.hanSuDung = hanSuDung;
        demThuoc++;
    }

    /**
     * Kiểm tra tính hợp lệ của hạn sử dụng:
     * - Định dạng chuẩn: dd/MM/yyyy (nghiêm ngặt theo lịch)
     * - Thuốc phải còn hạn sử dụng (từ hôm nay trở đi)
     * - Năm tối đa 2050
     */
    public static boolean kiemTraHanSuDung(String hsd) {
        if (hsd == null) return false;
        String s = hsd.trim();
        if (!s.matches("^\\d{2}/\\d{2}/\\d{4}$")) {
            return false;
        }
        try {
            LocalDate date = LocalDate.parse(s, DATE_FORMATTER);
            LocalDate now = LocalDate.now();
            if (date.isBefore(now)) {
                return false; // Thuốc đã hết hạn
            }
            if (date.getYear() > 2050) {
                return false;
            }
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    /**
     * Kiểm tra thuốc/vật tư đã hết hạn sử dụng tính đến hôm nay chưa
     * (hạn đọc từ file không đúng định dạng cũng coi như hết hạn để không bán nhầm)
     */
    public boolean daHetHan() {
        if (hanSuDung == null) return true;
        try {
            LocalDate han = LocalDate.parse(hanSuDung.trim(), DATE_FORMATTER);
            return han.isBefore(LocalDate.now());
        } catch (DateTimeParseException e) {
            return true;
        }
    }

    // ===== Getter và Setter =====

    public String getMaThuoc() {
        return maThuoc;
    }

    public void setMaThuoc(String maThuoc) {
        this.maThuoc = maThuoc;
    }

    public String getTenThuoc() {
        return tenThuoc;
    }

    public void setTenThuoc(String tenThuoc) {
        this.tenThuoc = tenThuoc;
    }

    public double getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(double giaBan) {
        this.giaBan = giaBan;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public String getHanSuDung() {
        return hanSuDung;
    }

    public void setHanSuDung(String hanSuDung) {
        this.hanSuDung = hanSuDung;
    }

    // Giữ tương thích ngược với getHanDung/setHanDung nếu có nơi gọi
    public String getHanDung() {
        return hanSuDung;
    }

    public void setHanDung(String hanDung) {
        this.hanSuDung = hanDung;
    }

    /**
     * Hiển thị tổng số đối tượng Thuoc đã tạo
     */
    public static void hienSoLuong() {
        System.out.println("Tổng số đối tượng Thuốc đã tạo: " + demThuoc);
    }

    /**
     * Phương thức trừu tượng - hiển thị thông tin chi tiết
     */
    public abstract void hienThongTin();

    /**
     * Phương thức trừu tượng - trả về loại thuốc
     */
    public abstract String getLoaiThuoc();
}
