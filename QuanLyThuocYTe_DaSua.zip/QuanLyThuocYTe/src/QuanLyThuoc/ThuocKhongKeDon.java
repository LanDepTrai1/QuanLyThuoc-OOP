package QuanLyThuoc;

/**
 * Lớp ThuocKhongKeDon - thuốc không cần đơn bác sĩ
 * Kế thừa từ lớp Thuoc
 */
public class ThuocKhongKeDon extends Thuoc {
    // Đếm số lượng thuốc không kê đơn đã tạo
    public static int demKhongKeDon = 0;

    /**
     * Constructor đầy đủ tham số
     */
    public ThuocKhongKeDon(String maThuoc, String tenThuoc, double giaBan, int soLuong, String hanSuDung) {
        super(maThuoc, tenThuoc, giaBan, soLuong, hanSuDung);
        demKhongKeDon++;
    }

    /**
     * Hiển thị số lượng thuốc không kê đơn đã tạo
     */
    public static void hienSoLuongKhongKeDon() {
        System.out.println("Tổng số Thuốc không kê đơn đã tạo: " + demKhongKeDon);
    }

    /**
     * Override - hiển thị đầy đủ thông tin thuốc không kê đơn
     */
    @Override
    public void hienThongTin() {
        System.out.println("+-------------------------------------------------+");
        System.out.println("| Loại thuốc   : " + getLoaiThuoc());
        System.out.println("| Mã thuốc     : " + getMaThuoc());
        System.out.println("| Tên thuốc    : " + getTenThuoc());
        System.out.println("| Giá bán      : " + String.format("%,.0f", getGiaBan()) + " VNĐ");
        System.out.println("| Số lượng     : " + getSoLuong());
        System.out.println("| Hạn sử dụng  : " + getHanSuDung());
        System.out.println("+-------------------------------------------------+");
    }

    /**
     * Override - trả về loại thuốc
     */
    @Override
    public String getLoaiThuoc() {
        return "Thuốc Không Kê Đơn";
    }
}
