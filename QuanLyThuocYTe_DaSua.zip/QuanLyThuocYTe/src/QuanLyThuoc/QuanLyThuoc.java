package QuanLyThuoc;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Lớp QuanLyThuoc - quản lý danh sách thuốc và vật tư y tế
 * Implements IThuocAction
 */
public class QuanLyThuoc implements IThuocAction {
    // Tên file mặc định
    private static final String FILE_MAC_DINH = "thuoc.txt";

    // Danh sách lưu trữ tất cả thuốc/vật tư
    private ArrayList<Thuoc> danhSach;
    // Scanner dùng chung để nhập dữ liệu
    private Scanner sc = new Scanner(System.in);
    // Thời điểm sửa đổi file lần cuối được nạp
    private long thoiGianDocFile = 0;

    /**
     * Constructor khởi tạo danh sách và tự động nạp dữ liệu từ file nếu có
     */
    public QuanLyThuoc() {
        danhSach = new ArrayList<>();
        File file = new File(FILE_MAC_DINH);
        if (file.exists()) {
            docFile(FILE_MAC_DINH);
        }
    }

    /**
     * Tự động kiểm tra và nạp lại file nếu file thuoc.txt bị chỉnh sửa từ bên ngoài
     */
    public void kiemTraVaNapLai() {
        File file = new File(FILE_MAC_DINH);
        if (file.exists() && file.lastModified() > thoiGianDocFile) {
            System.out.println(">>> Phát hiện file " + FILE_MAC_DINH + " vừa có thay đổi từ bên ngoài, đang tự động đồng bộ lại...");
            docFile(FILE_MAC_DINH);
        }
    }

    public void setScanner(Scanner sc) {
        if (sc != null) this.sc = sc;
    }

    public ArrayList<Thuoc> getDanhSach() {
        kiemTraVaNapLai();
        return danhSach;
    }

    /**
     * Tìm thuốc theo mã
     */
    public Thuoc timTheoMa(String maThuoc) {
        kiemTraVaNapLai();
        if (maThuoc == null) return null;
        for (Thuoc t : danhSach) {
            if (t.getMaThuoc().equalsIgnoreCase(maThuoc.trim())) {
                return t;
            }
        }
        return null;
    }

    // ==================== THÊM ====================
    /**
     * Thêm mới một thuốc hoặc vật tư vào danh sách
     */
    @Override
    public void them() {
        System.out.println("\n===== THÊM MỚI THUỐC / VẬT TƯ =====");
        int loai = 0;
        do {
            System.out.println("Chọn loại thuốc / vật tư:");
            System.out.println("  1. Thuốc kê đơn");
            System.out.println("  2. Thuốc không kê đơn");
            System.out.println("  3. Vật tư y tế");
            System.out.print("Nhập lựa chọn của bạn: ");
            try {
                loai = Integer.parseInt(sc.nextLine().trim());
                if (loai >= 1 && loai <= 3) break;
                System.out.println("[!] Lựa chọn không hợp lệ! Vui lòng chỉ chọn từ 1 đến 3.");
            } catch (NumberFormatException e) {
                System.out.println("[!] Vui lòng nhập số từ 1 đến 3!");
            }
        } while (true);

        // Nhập thông tin chung
        String ma = "";
        do {
            System.out.print("Mã thuốc/vật tư: ");
            ma = sc.nextLine().trim();
            if (ma.isEmpty()) {
                System.out.println("[!] Mã không được để trống!");
                continue;
            }
            if (ma.contains("|")) {
                System.out.println("[!] Mã không được chứa ký tự '|'!");
                continue;
            }
            if (timTheoMa(ma) != null) {
                System.out.println("[!] Mã đã tồn tại trong danh sách!");
                return;
            }
            break;
        } while (true);

        String ten = "";
        do {
            System.out.print("Tên thuốc/vật tư: ");
            ten = sc.nextLine().trim().replace("|", "-");
            if (ten.isEmpty()) {
                System.out.println("[!] Tên không được để trống!");
                continue;
            }
            break;
        } while (true);

        double gia = 0;
        do {
            System.out.print("Giá bán (> 0 VNĐ): ");
            try {
                gia = Double.parseDouble(sc.nextLine().trim());
                if (gia <= 0) {
                    System.out.println("[!] Giá bán phải lớn hơn 0!");
                    continue;
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println("[!] Giá bán không hợp lệ! Vui lòng nhập số.");
            }
        } while (true);

        int soLuong = 0;
        do {
            System.out.print("Số lượng (> 0)   : ");
            try {
                soLuong = Integer.parseInt(sc.nextLine().trim());
                if (soLuong <= 0) {
                    System.out.println("[!] Số lượng phải lớn hơn 0!");
                    continue;
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println("[!] Số lượng không hợp lệ! Vui lòng nhập số nguyên.");
            }
        } while (true);

        // Ràng buộc hạn sử dụng: định dạng dd/MM/yyyy, lịch thực tế, chưa hết hạn, <= 2050
        String hanSuDung = "";
        do {
            System.out.print("Hạn sử dụng (dd/MM/yyyy): ");
            hanSuDung = sc.nextLine().trim();
            if (!Thuoc.kiemTraHanSuDung(hanSuDung)) {
                System.out.println("[!] Hạn sử dụng không hợp lệ!");
                System.out.println("[!] Yêu cầu: Định dạng dd/MM/yyyy, ngày lịch chuẩn, thuốc phải còn hạn (sau hôm nay) và năm tối đa 2050. Vui lòng nhập lại.");
                continue;
            }
            break;
        } while (true);

        // Nhập thông tin riêng theo loại
        switch (loai) {
            case 1: {
                danhSach.add(new ThuocKeDon(ma, ten, gia, soLuong, hanSuDung));
                System.out.println("[✓] Đã thêm Thuốc kê đơn thành công!");
                ghiFile(FILE_MAC_DINH);
                break;
            }
            case 2: {
                danhSach.add(new ThuocKhongKeDon(ma, ten, gia, soLuong, hanSuDung));
                System.out.println("[✓] Đã thêm Thuốc không kê đơn thành công!");
                ghiFile(FILE_MAC_DINH);
                break;
            }
            case 3: {
                System.out.print("Loại vật tư: ");
                String loaiVT = sc.nextLine().trim().replace("|", "-");
                System.out.print("Nhà sản xuất: ");
                String nsx = sc.nextLine().trim().replace("|", "-");
                danhSach.add(new VatTuYTe(ma, ten, gia, soLuong, hanSuDung, loaiVT, nsx));
                System.out.println("[✓] Đã thêm Vật tư y tế thành công!");
                ghiFile(FILE_MAC_DINH);
                break;
            }
        }
    }

    // ==================== SỬA ====================
    /**
     * Sửa thông tin thuốc theo mã
     */
    @Override
    public void sua() {
        System.out.println("\n===== SỬA THÔNG TIN THUỐC / VẬT TƯ =====");
        System.out.print("Nhập mã thuốc cần sửa: ");
        String ma = sc.nextLine().trim();

        Thuoc timDuoc = timTheoMa(ma);
        if (timDuoc == null) {
            System.out.println("[!] Không tìm thấy thuốc có mã: " + ma);
            return;
        }

        // Hiển thị thông tin hiện tại
        timDuoc.hienThongTin();

        System.out.println("\nNhập thông tin mới (bấm Enter để giữ nguyên):");

        System.out.print("Tên thuốc [" + timDuoc.getTenThuoc() + "]: ");
        String tenMoi = sc.nextLine().trim().replace("|", "-");
        if (!tenMoi.isEmpty()) timDuoc.setTenThuoc(tenMoi);

        System.out.print("Giá bán [" + timDuoc.getGiaBan() + "]: ");
        String giaMoi = sc.nextLine().trim();
        if (!giaMoi.isEmpty()) {
            try {
                double g = Double.parseDouble(giaMoi);
                if (g > 0) {
                    timDuoc.setGiaBan(g);
                } else {
                    System.out.println("[!] Giá bán phải lớn hơn 0, giữ nguyên giá cũ.");
                }
            } catch (NumberFormatException e) {
                System.out.println("[!] Giá không hợp lệ, giữ nguyên giá cũ.");
            }
        }

        System.out.print("Số lượng [" + timDuoc.getSoLuong() + "]: ");
        String slMoi = sc.nextLine().trim();
        if (!slMoi.isEmpty()) {
            try {
                int sl = Integer.parseInt(slMoi);
                // Cho phép 0 (kiểm kê thấy đã hết hàng), không cho số âm
                if (sl >= 0) {
                    timDuoc.setSoLuong(sl);
                } else {
                    System.out.println("[!] Số lượng không được âm, giữ nguyên.");
                }
            } catch (NumberFormatException e) {
                System.out.println("[!] Số lượng không hợp lệ, giữ nguyên.");
            }
        }

        System.out.print("Hạn sử dụng mới [" + timDuoc.getHanSuDung() + "] (dd/MM/yyyy, Enter để giữ nguyên): ");
        String hdMoi = sc.nextLine().trim();
        if (!hdMoi.isEmpty()) {
            if (Thuoc.kiemTraHanSuDung(hdMoi)) {
                timDuoc.setHanSuDung(hdMoi);
            } else {
                System.out.println("[!] Hạn sử dụng không hợp lệ hoặc đã hết hạn, giữ nguyên hạn cũ.");
            }
        }

        // Sửa thêm field riêng theo loại (chỉ có VatTuYTe còn field riêng)
        if (timDuoc instanceof VatTuYTe) {
            VatTuYTe vtyt = (VatTuYTe) timDuoc;
            System.out.print("Loại vật tư [" + vtyt.getLoaiVatTu() + "]: ");
            String lvt = sc.nextLine().trim().replace("|", "-");
            if (!lvt.isEmpty()) vtyt.setLoaiVatTu(lvt);

            System.out.print("Nhà sản xuất [" + vtyt.getNhaSanXuat() + "]: ");
            String nsx = sc.nextLine().trim().replace("|", "-");
            if (!nsx.isEmpty()) vtyt.setNhaSanXuat(nsx);
        }

        System.out.println("[✓] Đã cập nhật thông tin thành công!");
        ghiFile(FILE_MAC_DINH);
    }

    // ==================== XÓA ====================
    /**
     * Xóa thuốc khỏi danh sách theo mã
     */
    @Override
    public void xoa() {
        System.out.println("\n===== XÓA THUỐC / VẬT TƯ =====");
        System.out.print("Nhập mã thuốc cần xóa: ");
        String ma = sc.nextLine().trim();

        Thuoc timDuoc = timTheoMa(ma);
        if (timDuoc == null) {
            System.out.println("[!] Không tìm thấy thuốc có mã: " + ma);
            return;
        }

        System.out.print("Bạn có chắc chắn muốn xóa [" + timDuoc.getTenThuoc() + "]? (c/k): ");
        String xacNhan = sc.nextLine().trim();
        if (xacNhan.equalsIgnoreCase("c") || xacNhan.equalsIgnoreCase("y")) {
            danhSach.remove(timDuoc);
            Thuoc.demThuoc--;
            // Giảm cả biến đếm của lớp con tương ứng
            if (timDuoc instanceof ThuocKeDon) {
                ThuocKeDon.demKeDon--;
            } else if (timDuoc instanceof ThuocKhongKeDon) {
                ThuocKhongKeDon.demKhongKeDon--;
            } else if (timDuoc instanceof VatTuYTe) {
                VatTuYTe.demVatTu--;
            }
            System.out.println("[✓] Đã xóa thành công!");
            ghiFile(FILE_MAC_DINH);
        } else {
            System.out.println("[!] Hủy thao tác xóa.");
        }
    }

    // ==================== TÌM KIẾM ====================
    /**
     * Tìm kiếm theo tên hoặc mã thuốc (không phân biệt hoa/thường, chứa chuỗi)
     */
    @Override
    public void timKiem() {
        kiemTraVaNapLai();
        System.out.println("\n===== TÌM KIẾM THUỐC / VẬT TƯ =====");
        System.out.print("Nhập tên hoặc mã cần tìm: ");
        String tuKhoa = sc.nextLine().trim();

        ArrayList<Thuoc> ketQua = new ArrayList<>();
        for (Thuoc t : danhSach) {
            if (t.getMaThuoc().toLowerCase().contains(tuKhoa.toLowerCase())
                    || t.getTenThuoc().toLowerCase().contains(tuKhoa.toLowerCase())) {
                ketQua.add(t);
            }
        }

        if (ketQua.isEmpty()) {
            System.out.println("[!] Không tìm thấy kết quả nào với từ khóa: \"" + tuKhoa + "\"");
        } else {
            System.out.println("Tìm thấy " + ketQua.size() + " kết quả:");
            for (Thuoc t : ketQua) {
                t.hienThongTin();
            }
        }
    }

    // ==================== HIỂN THỊ ====================
    /**
     * Hiển thị toàn bộ danh sách dưới dạng bảng
     */
    @Override
    public void hienDanhSach() {
        kiemTraVaNapLai();
        System.out.println("\n===== DANH SÁCH THUỐC VÀ VẬT TƯ Y TẾ =====");
        if (danhSach.isEmpty()) {
            System.out.println("  (Danh sách trống)");
            return;
        }
        System.out.printf("%-4s %-10s %-25s %-22s %14s %10s %-14s%n",
                "STT", "Mã", "Tên thuốc", "Loại", "Giá bán (VNĐ)", "Số lượng", "Hạn sử dụng");
        System.out.println("-".repeat(102));
        int stt = 1;
        for (Thuoc t : danhSach) {
            System.out.printf("%-4d %-10s %-25s %-22s %,14.0f %10d %-14s%n",
                    stt++,
                    t.getMaThuoc(),
                    t.getTenThuoc(),
                    t.getLoaiThuoc(),
                    t.getGiaBan(),
                    t.getSoLuong(),
                    t.getHanSuDung());
        }
        System.out.println("-".repeat(102));
        System.out.println("Tổng số: " + danhSach.size() + " bản ghi.");
    }

    // ==================== ĐỌC FILE ====================
    @Override
    public void docFile(String tenFile) {
        File f = new File(tenFile);
        if (!f.exists()) {
            System.out.println("[!] Không tìm thấy file: " + tenFile);
            return;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(f, StandardCharsets.UTF_8))) {
            String dongHienTai;
            int soLuongDoc = 0;
            danhSach.clear(); // Xóa danh sách cũ trước khi đọc
            Thuoc.demThuoc = 0;
            ThuocKeDon.demKeDon = 0;
            ThuocKhongKeDon.demKhongKeDon = 0;
            VatTuYTe.demVatTu = 0;

            while ((dongHienTai = br.readLine()) != null) {
                dongHienTai = dongHienTai.trim();
                if (dongHienTai.isEmpty()) continue;

                String[] phan = dongHienTai.split("\\|");
                if (phan.length < 6) {
                    continue;
                }

                try {
                    String ma = phan[0].trim();
                    String ten = phan[1].trim();
                    double gia = Double.parseDouble(phan[2].trim());
                    int soLuong = Integer.parseInt(phan[3].trim());
                    String hanSuDung = phan[4].trim();
                    String loai = phan[5].trim();

                    switch (loai) {
                        case "KD":
                            danhSach.add(new ThuocKeDon(ma, ten, gia, soLuong, hanSuDung));
                            soLuongDoc++;
                            break;
                        case "KKD":
                            danhSach.add(new ThuocKhongKeDon(ma, ten, gia, soLuong, hanSuDung));
                            soLuongDoc++;
                            break;
                        case "VT":
                            String loaiVT = phan.length > 6 ? phan[6].trim() : "";
                            String nsx = phan.length > 7 ? phan[7].trim() : "";
                            danhSach.add(new VatTuYTe(ma, ten, gia, soLuong, hanSuDung, loaiVT, nsx));
                            soLuongDoc++;
                            break;
                        default:
                            // Không thêm vào danh sách nên cũng không đếm
                            System.out.println("[!] Loại không xác định: " + loai + " (bỏ qua dòng: " + dongHienTai + ")");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("[!] Lỗi dữ liệu số trên dòng: " + dongHienTai);
                }
            }
            thoiGianDocFile = f.lastModified();
            System.out.println("[✓] Tự động tải " + soLuongDoc + " thuốc/vật tư từ file: " + tenFile);
        } catch (IOException e) {
            System.out.println("[!] Không thể đọc file: " + tenFile + " (" + e.getMessage() + ")");
        }
    }

    // ==================== GHI FILE ====================
    @Override
    public void ghiFile(String tenFile) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(tenFile, StandardCharsets.UTF_8))) {
            for (Thuoc t : danhSach) {
                StringBuilder sb = new StringBuilder();
                sb.append(t.getMaThuoc()).append("|");
                sb.append(t.getTenThuoc()).append("|");
                sb.append(t.getGiaBan()).append("|");
                sb.append(t.getSoLuong()).append("|");
                sb.append(t.getHanSuDung()).append("|");

                if (t instanceof ThuocKeDon) {
                    sb.append("KD");
                } else if (t instanceof ThuocKhongKeDon) {
                    sb.append("KKD");
                } else if (t instanceof VatTuYTe) {
                    VatTuYTe vtyt = (VatTuYTe) t;
                    sb.append("VT|");
                    sb.append(vtyt.getLoaiVatTu()).append("|");
                    sb.append(vtyt.getNhaSanXuat());
                }

                bw.write(sb.toString());
                bw.newLine();
            }
            thoiGianDocFile = new File(tenFile).lastModified();
            System.out.println("[✓] Tự động cập nhật file: " + tenFile);
        } catch (IOException e) {
            System.out.println("[!] Không thể ghi file: " + tenFile + " (" + e.getMessage() + ")");
        }
    }

    // ==================== MENU ====================
    public void hienMenu() {
        hienMenu(this.sc);
    }

    public void hienMenu(Scanner sc) {
        this.sc = sc;
        kiemTraVaNapLai();
        int luaChon = -1;
        do {
            System.out.println("\n╔══════════════════════════════════╗");
            System.out.println("║     QUẢN LÝ THUỐC & VẬT TƯ       ║");
            System.out.println("╠══════════════════════════════════╣");
            System.out.println("║  1. Thêm thuốc / vật tư          ║");
            System.out.println("║  2. Sửa thông tin                ║");
            System.out.println("║  3. Xóa thuốc / vật tư           ║");
            System.out.println("║  4. Tìm kiếm                     ║");
            System.out.println("║  5. Hiển thị danh sách           ║");
            System.out.println("║  6. Đọc dữ liệu từ file          ║");
            System.out.println("║  7. Ghi dữ liệu ra file          ║");
            System.out.println("║  0. Quay lại menu trước          ║");
            System.out.println("╚══════════════════════════════════╝");
            System.out.print("Nhập lựa chọn của bạn: ");

            try {
                luaChon = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println(">>> Vui lòng nhập số!");
                continue;
            }

            switch (luaChon) {
                case 1: them(); break;
                case 2: sua(); break;
                case 3: xoa(); break;
                case 4: timKiem(); break;
                case 5: hienDanhSach(); break;
                case 6:
                    System.out.print("Nhập tên file cần đọc: ");
                    String fileDoc = sc.nextLine().trim();
                    docFile(fileDoc);
                    break;
                case 7:
                    System.out.print("Nhập tên file cần ghi: ");
                    String fileGhi = sc.nextLine().trim();
                    ghiFile(fileGhi);
                    break;
                case 0:
                    break;
                default:
                    System.out.println(">>> Lựa chọn không hợp lệ! Vui lòng chọn từ 0-7.");
            }
        } while (luaChon != 0);
    }
}
